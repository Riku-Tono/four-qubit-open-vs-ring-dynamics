"""Continuous-time lower bounds and deterministic weak-link upper witnesses.

The optimization/search stages choose witnesses. The certificates independently
evaluate probabilities by a segmented Taylor polynomial and cover both axes by
analytic Lipschitz inequalities. Run from the directory containing the original
finite_shot_topology.py (or add it to PYTHONPATH).
"""

import json
import math
from decimal import Decimal, localcontext
from pathlib import Path

import numpy as np
from scipy.optimize import brentq

import finite_shot_topology as ft


STEP = 0.25
ORDER = 18
ROOT_ERROR = 2e-11
CHORD_ERROR = 2 * ROOT_ERROR + 1e-12
TIME_SPEED = 2.0
LINK_SPEED = 0.35 * ft.T_MAX
LOG20 = math.log(20)
COARSE = np.linspace(0.0, ft.T_MAX, 923)
ORIGINAL_N = {0.0: 62, 0.02: 80, 0.05: 106}
PUBLISHED = {
    0.0: [('X', 2.272, 28), ('Z', 2.028, 7), ('Z', 2.376, 4), ('Z', 3.176, 10), ('Z', 3.688, 13)],
    0.02: [('Z', 2.112, 70), ('Z', 3.280, 10)],
    0.05: [('X', 2.260, 5), ('Z', 2.104, 90), ('Z', 3.036, 11)],
}
EXACT_ROTATIONS = {b: np.round(r * 4) / 4 for b, r in ft.ROT.items()}
with localcontext() as _ctx:
    _ctx.prec = 50
    REQUIRED_BHATTA = -(Decimal(2) * (Decimal('0.05') * Decimal('0.95')).sqrt()).ln()


class TaylorPropagator:
    """Degree 18 on dyadic quarter-time steps, including residual intervals.

    |H| has both induced 1- and infinity-norm at most 4.1 + 5e-15,
    including Hamiltonian coefficient roundoff. Thus || |H| / 4 ||_2 < 1.026.
    The order-18 exponential remainder is below 2e-17. For IEEE binary64,
    let gamma_k = k*u/(1-k*u), u=2**-53. Per polynomial, 18 real
    length-16 matrix-product recurrences, their scales and summation fit
    within gamma_900 * exp(1.026) < 2.9e-13 in induced 2-norm using
    componentwise absolute values. Each length-16 complex application
    adds at most gamma_128 * exp(1.026) < 4.0e-14. The 14 quarter steps
    and one residual polynomial accumulate less than 6e-12 in state norm
    by unitarity of the exact steps. Hamiltonian rounding contributes less
    than T_MAX * 5e-15. Exact signed-quarter basis rotations and positive
    readout mixing contribute less than 1e-12 to the square-root
    probability vector, by the reverse triangle inequality on each
    outcome's vector of weighted amplitudes. ROOT_ERROR is 2e-11.
    """

    def __init__(self, h):
        coefficients = [np.eye(16)]
        for order in range(1, ORDER + 1):
            coefficients.append(h @ coefficients[-1] * (STEP / order))
        phases = np.array([1, -1j, -1, 1j])[np.arange(ORDER + 1) % 4]
        self.coefficients = np.array(coefficients) * phases[:, None, None]
        step = self.coefficients.sum(axis=0)
        state = np.zeros(16, dtype=complex)
        state[0] = 1
        anchors = [state]
        for _ in range(int(ft.T_MAX / STEP)):
            anchors.append(step @ anchors[-1])
        self.local = self.coefficients @ np.array(anchors).T

    def roots(self, times, p):
        segment = (times / STEP).astype(int)
        residual = times / STEP - segment
        powers = np.ones((len(times), ORDER + 1))
        for order in range(1, ORDER + 1):
            powers[:, order] = powers[:, order - 1] * residual
        states = np.einsum('tk,kti->ti', powers, self.local[:, :, segment].transpose(0, 2, 1))
        flip = ft.flip_matrix(p)
        amplitudes = np.array([states @ EXACT_ROTATIONS[b].T for b in ft.BASES])
        probabilities = amplitudes.real ** 2 + amplitudes.imag ** 2
        return np.sqrt(probabilities @ flip.T)


def chord_upper(a, b):
    return np.linalg.norm(a - b, axis=-1) + CHORD_ERROR


def bhatta_upper(chord):
    """Upper bound on -log(1-||sqrt(P)-sqrt(Q)||^2/2) by a positive series."""
    x = chord ** 2 / 2 + 1e-14
    if np.max(x) >= 1:
        return np.full_like(x, np.inf)
    power = x.copy()
    terms = power.copy()
    for k in range(2, 129):
        power *= x
        terms += power / k
    return terms + power * x / (129 * (1 - x)) + 1e-12


def necessary_chord(n):
    with localcontext() as ctx:
        ctx.prec = 50
        return float((2 * (1 - (-REQUIRED_BHATTA/n).exp())).sqrt()) - 1e-12


def topology_lower():
    """Only one dual candidate pair per permutation orbit is needed for the LP."""
    pairs = np.array(sorted({ft.orbit_key(a, b) for a, b in ft.GP}))
    nt = len(COARSE)
    cert_times = np.linspace(0.0, ft.T_MAX, 7377)
    result = {}
    for p in ft.P_FLIPS:
        roots = np.sqrt(ft.grid_probs(COARSE, p))
        B = np.column_stack([-np.log(np.clip((roots[a] * roots[b]).sum(axis=1), 1e-300, 1))
                             for a, b in pairs])
        w, lp_value, q = ft.maximin_design(B)
        active = np.where(q > 1e-10)[0]
        q = q[active]
        q /= q.sum()
        active_pairs = pairs[active]
        graph_ids = sorted(set(active_pairs.flatten()))
        exact_roots = {g: TaylorPropagator(ft.hamiltonian(ft.GRAPHS[g])).roots(cert_times, p) for g in graph_ids}
        envelopes = []
        for a, b in active_pairs:
            chord = chord_upper(exact_roots[a], exact_roots[b]) + 0.0005000000001
            envelopes.append(bhatta_upper(chord))
        dual_upper = float(np.max(np.tensordot(q, envelopes, axes=1))) + 1e-12
        real_lower = (float(REQUIRED_BHATTA) - 1e-12) / dual_upper
        support = np.flatnonzero(w > 1e-5)
        settings, wd = ft.merge_close([(ft.BASES[s // nt], float(COARSE[s % nt])) for s in support], w[support])
        wd /= wd.sum()
        result[str(p)] = dict(grid_dt=0.0005, dual_upper=dual_upper, real_lower=real_lower,
                              integer_lower=math.ceil(real_lower), lp_value=lp_value,
                              dual_pairs=[dict(a=int(a), b=int(b), weight=float(z)) for (a, b), z in zip(active_pairs, q)],
                              settings=settings, weights=wd.tolist())
        print(f'topology p={p:g}: {real_lower:.9f} → {math.ceil(real_lower)}', flush=True)
    return result


class WeakAudit:
    def __init__(self, p):
        self.p = p
        self.base = TaylorPropagator(ft.hamiltonian(ft.OPEN))
        self.coarse_base = self.base.roots(COARSE, p)

    def alt(self, lam):
        return TaylorPropagator(ft.hamiltonian(ft.OPEN, {(0, 3): lam}))

    def roots(self, lam):
        return self.alt(lam).roots(COARSE, self.p)

    def point_chords(self, lam):
        return chord_upper(self.coarse_base, self.roots(lam))

    def time_upper(self, lam, limit, times, base_roots, tol=1e-7):
        """Prove the Hellinger chord upper bound below limit or return None."""
        alt = self.alt(lam)
        chord = chord_upper(base_roots, alt.roots(times, self.p)).max(axis=0)
        if chord.max() >= limit:
            return None
        a, b = times[:-1], times[1:]
        chord_a, chord_b = chord[:-1], chord[1:]
        max_certified = 0.0
        for _ in range(16):
            # Each cell is bounded by the minimum of the two endpoint cones.
            bound = (chord_a + chord_b + TIME_SPEED * (b - a)) / 2 + 1e-12
            safe = bound < limit
            max_certified = max(max_certified, float(bound[safe].max(initial=0)))
            if np.all(safe):
                return max_certified
            a, b = a[~safe], b[~safe]
            chord_a, chord_b = chord_a[~safe], chord_b[~safe]
            if np.min(b - a) < tol:
                return None
            mid = (a + b) / 2
            middle = chord_upper(self.base.roots(mid, self.p), alt.roots(mid, self.p)).max(axis=0)
            if middle.max() >= limit:
                return None
            a, b = np.concatenate([a, mid]), np.concatenate([mid, b])
            chord_a, chord_b = np.concatenate([chord_a, middle]), np.concatenate([middle, chord_b])
        return None

    def cover(self, endpoint, target, n):
        times = COARSE if n < 10_000 else np.linspace(0.0, ft.T_MAX, 3689)
        base_roots = self.coarse_base if n < 10_000 else self.base.roots(times, self.p)
        cells = [(0.0, endpoint)]
        certified = []
        while cells:
            a, b = cells.pop()
            mid = (a + b) / 2
            extra = LINK_SPEED * (b - a) / 2 + 1e-12
            time_bound = self.time_upper(mid, target - extra, times, base_roots)
            if time_bound is not None:
                certified.append((a, b, mid, time_bound, time_bound + extra))
            elif b - a < 1e-8:
                return None
            else:
                cells.extend([(a, mid), (mid, b)])
        return sorted(certified)

    def lower(self, n):
        # Bracketing only proposes an endpoint; the covering proof tests every cell.
        chord_limit = necessary_chord(n)
        coarse_root = brentq(lambda lam: self.point_chords(lam).max() - chord_limit, 0.0, 1.0)
        for safety in (0.002, 0.004, 0.008, 0.016, 0.032):
            endpoint = math.floor(coarse_root * (1 - safety) * 1e6) / 1e6
            certificate = self.cover(endpoint, chord_limit, n)
            if certificate is not None:
                return dict(impossible_through=endpoint, coarse_grid_crossing=coarse_root,
                            chord_limit=chord_limit, intervals=certificate)
        raise RuntimeError(f'weak-link lower certification failed for p={self.p}, n={n}')

    def upper(self, n):
        # Symmetric Chernoff s=1/2 proposes λ and a setting. Verify the actual
        # deterministic score rule with two separately bounded expectations.
        coarse_root = brentq(lambda lam: self.point_chords(lam).max() - math.sqrt(-2*math.expm1(-LOG20/n)),
                             0.0, 1.0)
        for safety in (0.002, 0.004, 0.008, 0.016, 0.032):
            lam = math.ceil(coarse_root * (1 + safety) * 1e6) / 1e6
            for ix in np.argsort(self.point_chords(lam).ravel())[-6:][::-1]:
                b, k = np.unravel_index(ix, (3, len(COARSE)))
                a = self.coarse_base[b, k]
                c = self.alt(lam).roots(COARSE[k:k+1], self.p)[b, 0]
                score = 2 * (np.log(np.maximum(c, 1e-14)) - np.log(np.maximum(a, 1e-14)))
                errors = tail_bounds(a, c, score, n)
                if max(errors) <= ft.EPS:
                    return dict(achievable_at=lam, coarse_bc_crossing=coarse_root, basis=ft.BASES[b],
                                time=float(COARSE[k]), error_upper=errors, scores=score.tolist(),
                                threshold=0.0, tilt=0.5)
        raise RuntimeError(f'weak-link upper certification failed for p={self.p}, n={n}')

    def fixed(self, schedule=None):
        schedule = PUBLISHED[self.p] if schedule is None else schedule
        bases = np.array([ft.BASES.index(b) for b, _, _ in schedule])
        times = np.array([t for _, t, _ in schedule])
        ns = np.array([n for _, _, n in schedule])
        idx = np.arange(len(times))
        roots0 = self.base.roots(times, self.p)[bases, idx]

        def roots1(lam):
            return self.alt(lam).roots(times, self.p)[bases, idx]

        def distance_upper(lam, radius):
            chord = chord_upper(roots0, roots1(lam)) + 0.35 * times * radius + 1e-12
            return float(ns @ bhatta_upper(chord)) + 1e-12

        required = float(REQUIRED_BHATTA) - 1e-12
        coarse_root = brentq(lambda lam: distance_upper(lam, 0) - required, 0.0, 1.0)
        endpoint = math.floor(coarse_root * 0.998 * 1e6) / 1e6
        cells = [(0.0, endpoint)]
        certified = []
        while cells:
            a, b = cells.pop()
            mid = (a + b) / 2
            total = distance_upper(mid, (b - a) / 2)
            if total < required:
                certified.append((a, b, mid, total))
            elif b - a < 1e-8:
                raise RuntimeError(f'fixed weak lower certification failed for p={self.p}')
            else:
                cells.extend([(a, mid), (mid, b)])

        def rule(lam):
            alt = roots1(lam)
            scores = 2 * (np.log(np.maximum(alt, 1e-14)) - np.log(np.maximum(roots0, 1e-14)))
            return multi_tail_bounds(roots0, alt, scores, ns), scores

        upper = None
        grid = np.linspace(endpoint, 1.0, 101)
        for lam in grid:
            errors, scores = rule(lam)
            if max(errors) <= ft.EPS:
                upper = dict(achievable_at=float(lam), error_upper=errors, scores=scores.tolist(),
                             threshold=0.0, tilt=0.5)
                break
        return dict(schedule=schedule, impossible_through=endpoint, coarse_crossing=coarse_root,
                    necessary_bhattacharyya=required, intervals=sorted(certified), upper=upper)


def tail_bounds(a, b, scores, n):
    """One-sided exponential Markov bounds for decision 1 iff sum scores >= 0."""
    return multi_tail_bounds([a], [b], [scores], [n])


def multi_tail_bounds(a, b, scores, ns):
    with localcontext() as ctx:
        ctx.prec = 50
        margin = Decimal('1e-35')
        epsilon = Decimal(str(ROOT_ERROR))
        dscore = [[Decimal.from_float(float(w)) for w in score] for score in scores]
        tails = []
        for roots, sign in ((a, 1), (b, -1)):
            total = Decimal(1)
            for settings_roots, settings_scores, n in zip(roots, dscore, ns):
                moment = sum((Decimal.from_float(float(r)) + epsilon) ** 2 * (w * sign / 2).exp()
                             for r, w in zip(settings_roots, settings_scores)) + margin
                total *= moment ** int(n)
            tails.append(float(total + margin) + 1e-12)
        return tails


def main():
    target = Path(__file__).with_name('math_bounds.json')
    result = dict(topology=topology_lower(), weak_link={}, fixed_weak_link={}, replay_weak_link={})
    target.write_text(json.dumps(result, indent=2), encoding='utf-8')
    for p in ft.P_FLIPS:
        audit = WeakAudit(p)
        fixed = result['fixed_weak_link'][str(p)] = audit.fixed()
        print(f'fixed weak p={p:g}: {fixed["impossible_through"]:.6f} < λ ≤ '
              f'{None if fixed["upper"] is None else fixed["upper"]["achievable_at"]}', flush=True)
        rows = result['weak_link'][str(p)] = {}
        if p == 0.05:
            replay_schedule = [('X', 2.260, 5), ('Z', 2.104, 89), ('Z', 3.036, 11)]
            replay = result['replay_weak_link']['0.05'] = dict(
                shots=105, global_lower=audit.lower(105), dedicated_upper=audit.upper(105),
                fixed=audit.fixed(replay_schedule))
            print(f'replay weak p=0.05, n=105: global lower {replay["global_lower"]["impossible_through"]:.6f}, '
                  f'fixed lower {replay["fixed"]["impossible_through"]:.6f}', flush=True)
            target.write_text(json.dumps(result, indent=2), encoding='utf-8')
        for n in (ORIGINAL_N[p], 1000, 10000, 100000):
            rows[str(n)] = dict(lower=audit.lower(n), upper=audit.upper(n))
            row = rows[str(n)]
            print(f'weak p={p:g}, n={n}: {row["lower"]["impossible_through"]:.6f} < λ ≤ '
                  f'{row["upper"]["achievable_at"]:.6f}, {len(row["lower"]["intervals"])} λ cells', flush=True)
            target.write_text(json.dumps(result, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
