"""Certify a constructive fixed-design weak-link test using integer arithmetic."""

import argparse
import csv
from fractions import Fraction as F
import json
from math import factorial, lcm
from pathlib import Path

import numpy as np

from audit_mc import PUBLISHED, replay_designs
import finite_shot_topology as model


TERMS = 72
MASS_SCALE = 1 << 32
SCORE_SCALE = 512
ERROR_LIMIT = F(1, 20)


def probabilities(basis, time, flip, strength):
    """Return exact rational approximations and a rigorous per-outcome error."""
    n = 16
    bonds = [(0, 1, F(1)), (1, 2, F(1)), (2, 3, F(1)), (0, 3, strength)]
    diagonal = []
    for x in range(n):
        signs = [1 - 2 * ((x >> (3 - k)) & 1) for k in range(4)]
        diagonal.append(time * F(7, 20) * sum(w * signs[a] * signs[b] for a, b, w in bonds))
    off_diagonal = time * F(1, 2)
    denominator = lcm(off_diagonal.denominator, *(d.denominator for d in diagonal))
    diag = [int(d * denominator) for d in diagonal]
    off = int(off_diagonal * denominator)
    norm = max(map(abs, diagonal)) + 4 * off_diagonal
    tail = norm ** (TERMS + 1) / factorial(TERMS + 1) / (1 - norm / (TERMS + 2))
    amplitude_scale = denominator**TERMS * factorial(TERMS)
    real = [0] * n
    imag = [0] * n
    vector = [1] + [0] * (n - 1)
    for k in range(TERMS + 1):
        target = real if k % 2 == 0 else imag
        factor = amplitude_scale // (denominator**k * factorial(k))
        if k % 4 in (1, 2):
            factor = -factor
        for x in range(n):
            target[x] += factor * vector[x]
        vector = [diag[x] * vector[x] + off * sum(vector[x ^ (1 << j)] for j in range(4)) for x in range(n)]

    if basis in ("X", "Y"):
        if basis == "Y":
            for x in range(n):
                phase = x.bit_count() % 4
                if phase == 1:
                    real[x], imag[x] = imag[x], -real[x]
                if phase == 2:
                    real[x], imag[x] = -real[x], -imag[x]
                if phase == 3:
                    real[x], imag[x] = -imag[x], real[x]
        signs = [[(-1) ** ((x & z).bit_count()) for z in range(n)] for x in range(n)]
        real = [sum(s * r for s, r in zip(row, real)) for row in signs]
        imag = [sum(s * r for s, r in zip(row, imag)) for row in signs]
        amplitude_scale *= 4
    ideal = [F(r*r + i*i, amplitude_scale**2) for r, i in zip(real, imag)]
    weights = [flip**d * (1-flip)**(4-d) for d in range(5)]
    observed = [sum(weights[(x ^ z).bit_count()] * ideal[z] for z in range(n)) for x in range(n)]
    return observed, (2 + tail) * tail


def lower_score_mass(settings, side):
    mass = np.array([MASS_SCALE], dtype=np.uint64)
    offset = 0
    for score, lower_probs, shots in settings:
        increments = np.unique(score)
        coefs = []
        for increment in increments:
            total = sum(lower_probs[side][int(i)] for i in np.flatnonzero(score == increment))
            coef = int(total * MASS_SCALE)
            assert 0 <= coef < MASS_SCALE
            coefs.append(np.uint64(coef))
        low, high = int(increments[0]), int(increments[-1])
        offsets = [int(i) - low for i in increments]
        for _ in range(shots):
            new_mass = np.zeros(len(mass) + high - low, dtype=np.uint64)
            for shift, coef in zip(offsets, coefs):
                new_mass[shift:shift + len(mass)] += (mass * coef) >> 32
            mass = new_mass
        offset += shots * low
    return mass, offset


def certificate(flip, strength, design):
    settings = []
    outcome_scores = []
    max_prob_error = F(0)
    for basis, time, shots in design:
        if shots == 0:
            continue
        time = F(str(time))
        a, err_a = probabilities(basis, time, flip, F(0))
        b, err_b = probabilities(basis, time, flip, strength)
        score = np.rint(SCORE_SCALE * (np.log(np.array(b, float)) - np.log(np.array(a, float)))).astype(int)
        lower_probs = [[max(F(0), p - err) for p in probs] for probs, err in ((a, err_a), (b, err_b))]
        max_prob_error = max(max_prob_error, err_a, err_b)
        settings.append((score, lower_probs, shots))
        outcome_scores.append(score.tolist())
    settings.sort(key=lambda row: int(np.ptp(row[0])))
    null, offset = lower_score_mass(settings, 0)
    alt, offset_alt = lower_score_mass(settings, 1)
    assert offset == offset_alt and len(null) == len(alt)
    null_error = MASS_SCALE - np.cumsum(null, dtype=np.uint64)
    alt_error = MASS_SCALE - (np.cumsum(alt[::-1], dtype=np.uint64)[::-1] - alt)
    index = int(np.argmin(np.maximum(null_error, alt_error)))
    errors = [F(int(counts[index]), MASS_SCALE) for counts in (null_error, alt_error)]
    return {
        "lambda": str(strength), "design": design, "threshold": offset + index,
        "outcome_scores": outcome_scores, "null_error_upper": float(errors[0]),
        "alt_error_upper": float(errors[1]), "null_error_upper_numerator": int(null_error[index]),
        "alt_error_upper_numerator": int(alt_error[index]), "error_upper_denominator": MASS_SCALE,
        "max_probability_approximation_error": float(max_prob_error), "pass": max(errors) <= ERROR_LIMIT,
    }


def dedicated(flip, strength, shots):
    ts = np.arange(0, model.T_MAX + 1e-12, 2 * model.DT_DESIGN)
    distances = model.weak_link_bhatta(float(flip), ts, float(strength))
    i = int(distances.argmax())
    return [(model.BASES[i // len(ts)], round(float(ts[i % len(ts)]), 3), shots)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--replay", type=Path, help="Also certify any changed designs in the replay JSON")
    args = parser.parse_args()
    start_lambdas = {0.0: ("0.55", "0.43"), 0.02: ("0.69", "0.44"), 0.05: ("0.69", "0.46")}
    cases = [("published", p, design) for p, (design, _) in PUBLISHED.items()]
    if args.replay is not None:
        for p, (design, _) in replay_designs(args.replay).items():
            canonical = [(basis, round(time, 3), shots) for basis, time, shots in design]
            if canonical != PUBLISHED[p][0]:
                cases.append(("replay", p, canonical))
    with args.output.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = None
        for family, p, fixed in cases:
            flip = F(str(p))
            shots = sum(n for _, _, n in fixed)
            for label, initial in zip(("64-way allocation", "dedicated"), start_lambdas[p]):
                for i in range(11):
                    strength = F(initial) + F(i, 100)
                    design = fixed if label == "64-way allocation" else dedicated(flip, strength, shots)
                    row = dict(family=family, p_flip=p, case=label, shots=shots)
                    row.update(certificate(flip, strength, design))
                    for key in ("design", "outcome_scores"):
                        row[key] = json.dumps(row[key], separators=(",", ":"))
                    if writer is None:
                        writer = csv.DictWriter(stream, fieldnames=row.keys())
                        writer.writeheader()
                    writer.writerow(row)
                    stream.flush()
                    print({k: v for k, v in row.items() if k not in ("outcome_scores",)}, flush=True)
                    if row["pass"]:
                        break


if __name__ == "__main__":
    main()
