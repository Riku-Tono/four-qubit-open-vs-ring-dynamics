"""Combine exact tilted Hunter results, taking the strongest per true graph."""
import argparse
import json
from pathlib import Path

import numpy as np

from certify_hunter_p5 import stabilizers
from certify_p5_integer_design import SCALE, graph_symmetry


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def merge(candidate, union, parts):
    assert union["denominator"] == SCALE
    for key in ("design", "integer_scores", "integer_bias"):
        assert candidate[key] == union[key]
    scores = np.array(candidate["integer_scores"], dtype=np.int64)
    bias = np.array(candidate["integer_bias"], dtype=np.int64)
    reps, classes, _ = graph_symmetry(scores, bias)
    reps_str = {str(g) for g in reps}
    starting = union["representative_upper_numerators"]
    assert set(starting) == reps_str
    sym = stabilizers(reps)

    uppers = {}
    forests = {}
    plans = {}
    blocks = {}
    possible_edges = {}
    for part in parts:
        assert part["denominator"] == SCALE
        for g, upper in part["representative_upper_numerators"].items():
            assert g in reps_str
            edges = part["forest"][g]
            graph_block = part["blocks"][g] if "blocks" in part else part["block"]
            graph_edges = possible_edges.setdefault(g, {})
            component = list(range(64))
            total = 0
            for edge in edges:
                h, j, mass = (edge[k] for k in ("rival1", "rival2", "intersection_lower_numerator"))
                assert 0 <= h < 64 and 0 <= j < 64 and int(g) not in (h,j)
                assert 0 < mass <= SCALE
                a, b = component[h], component[j]
                assert a != b, "not a forest"
                component = [a if c == b else c for c in component]
                total += mass
                key = tuple(sorted((h,j)))
                canon = min(tuple(sorted((m[h],m[j]))) for m in sym[int(g)])
                edge_block = edge.get("block", graph_block)
                suffix = f"{canon[0]},{canon[1]}"
                plan_key = suffix if edge_block == graph_block else f"{edge_block}:{suffix}"
                if key not in graph_edges or mass > graph_edges[key][0]:
                    graph_edges[key] = (mass, edge_block, suffix, part["plans"][g][plan_key])
            assert upper == starting[g] - total >= 0
            if g not in uppers or upper < uppers[g]:
                uppers[g] = upper
                forests[g] = edges
                plans[g] = part["plans"][g]
                blocks[g] = graph_block
    for g, choices in possible_edges.items():
        component = list(range(64))
        edges, selected = [], {}
        total = 0
        # A plan is shared by all copies of one intersection under symmetry.
        # If independent runs clipped it differently, keep the first plan
        # chosen for that orbit and use its bound consistently for all copies.
        orbit_weights = {}
        for (h,j), (mass, edge_block, suffix, plan) in sorted(
            choices.items(), key=lambda pair: pair[1][0], reverse=True,
        ):
            a, b = component[h], component[j]
            if a == b:
                continue
            plan_key = suffix if edge_block == blocks[g] else f"{edge_block}:{suffix}"
            mass, plan = orbit_weights.setdefault(plan_key, (mass, plan))
            component = [a if c == b else c for c in component]
            edge = dict(rival1=h,rival2=j,intersection_lower_numerator=mass)
            if edge_block != blocks[g]:
                edge["block"] = edge_block
            edges.append(edge)
            selected[plan_key] = plan
            total += mass
        new_upper = starting[g] - total
        assert new_upper >= 0
        if new_upper < uppers[g]:
            uppers[g], forests[g], plans[g] = new_upper, edges, selected
    missing = reps_str - uppers.keys()
    worst = max(uppers.values())
    print("missing", sorted(missing), "over", [(g,x/SCALE) for g,x in uppers.items() if 20*x>SCALE])
    return dict(denominator=SCALE, blocks=blocks, representative_upper_numerators=uppers,
                graph_upper_numerators=[uppers.get(str(int(reps[classes[g]]))) for g in range(64)],
                forest=forests, plans=plans, worst_numerator=worst,
                certifies_all_64_at_95=not missing and 20*worst<=SCALE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--union", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("parts", type=Path, nargs="+")
    args = parser.parse_args()
    result = merge(load(args.candidate), load(args.union), [load(p) for p in args.parts])
    args.output.write_text(json.dumps(result,separators=(",",":"))+"\n",encoding="utf-8")
    print("worst",result["worst_numerator"]/SCALE,"verified",result["certifies_all_64_at_95"],flush=True)


if __name__ == "__main__":
    main()
