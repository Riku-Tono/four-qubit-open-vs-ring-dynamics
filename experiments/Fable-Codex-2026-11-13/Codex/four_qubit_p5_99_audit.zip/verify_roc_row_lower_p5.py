"""Certified lower bound from several competing labels sharing one error row."""
import argparse
from fractions import Fraction as F
import json
from pathlib import Path

import numpy as np

from verify_roc_lower_p5 import (
    MASS_SCALE, RATIO_BASE, EPS, STEPS, S, fraction_floor,
    lower_convolution, node_laws, quantized_laws, roc_hull, weighted_envelopes,
)
from verify_joint_confusion_lower import log_threshold_lower, site_maps

NULL = 31


def minimum_size_lower(schedules):
    origin, p = lower_convolution(schedules,0)
    origin_q,q = lower_convolution(schedules,1)
    assert origin == origin_q and len(p) == len(q)
    null = np.cumsum(p,dtype=np.uint64)
    alt = np.cumsum(q,dtype=np.uint64)
    center = int(np.searchsorted(alt,(EPS*MASS_SCALE).__floor__()))
    options = []
    for k in range(max(0,center-6),min(len(alt),center+7)):
        null_tail = F(int(null[-1])-int(null[k]),MASS_SCALE)
        alt_tail_upper = 1-F(int(alt[k]),MASS_SCALE)
        ratio = RATIO_BASE**(origin+k)
        bound = null_tail + (1-EPS-alt_tail_upper)/ratio
        options.append((bound,origin+k))
    return max(options,default=(F(0),0))


def settings_above(envelopes, denom, cutoff):
    threshold = denom*cutoff
    return {
        (j,b) for i in range(STEPS) for b in range(3)
        if max(envelopes[i][b],envelopes[i+1][b]) >= threshold
        for j in (i,i+1)
    }


def permitted_counts(n, d, m, cuts):
    slack = n*m-d
    if len(cuts) == 1:
        bad = min(n,(slack/(m-cuts[0])).__floor__())
        return [(bad,n-bad)]
    low,high = cuts
    result = []
    for bad in range(min(n,(slack/(m-low)).__floor__())+1):
        middle = min(n-bad,((slack-bad*(m-low))/(m-high)).__floor__())
        result.append((bad,middle,n-bad-middle))
    return result


def run(witness, cases):
    pairs = witness["pair_weights"]
    tangents = [F(v) for v in witness["log_tangents"]]
    affinities = [[F(v) for v in row] for row in witness["affinity_tangents"]]
    d = fraction_floor(log_threshold_lower(pairs,tangents,affinities),10**15)
    graphs = {NULL}|{g for a,b,_ in pairs for g in (a,b)}
    graphs.update(row[0] for case in cases for row in case["alternatives"])
    laws = {}
    for g in sorted(graphs):
        laws[g] = node_laws(g)
        print("endpoint laws",g,flush=True)
    envelopes = weighted_envelopes(pairs,laws)
    denom = S*sum(w for _,_,w in pairs)
    m = F(max(max(r) for r in envelopes),denom)
    all_nodes = {(i,b) for i in range(STEPS+1) for b in range(3)}
    subsets = {F(0):all_nodes}
    experiments = {}
    mappings = [x for x in site_maps() if x[NULL] == NULL]
    results = []
    for case in cases:
        n = case["shots"]
        assert n*m >= d
        covered = set()
        lower = F(0)
        rows = []
        for g,*cutoff in case["alternatives"]:
            cuts = list(map(F,cutoff))
            assert 1 <= len(cuts) <= 2 and 0 < cuts[0] <= cuts[-1] < m
            assert NULL != g
            orbit = {x[g] for x in mappings}
            assert not covered.intersection(orbit)
            covered.update(orbit)
            choices = permitted_counts(n,d,m,cuts)
            for cut in [F(0)]+cuts:
                if cut not in subsets:
                    subsets[cut] = settings_above(envelopes,denom,cut)
                key = (g,cut)
                if key not in experiments:
                    hull = roc_hull(subsets[cut],laws[NULL],laws[g])
                    experiments[key] = quantized_laws(hull)
            dominant = [experiments[(g,cut)] for cut in [F(0)]+cuts]
            bounds = []
            for counts in choices:
                val,score = minimum_size_lower(list(zip(dominant,counts,strict=True)))
                bounds.append((val,counts,score))
            val,counts,score = min(bounds)
            val = max(F(0),fraction_floor(val,10**15))
            print(n,g,len(orbit),cuts,float(val),counts,len(bounds),flush=True)
            lower += len(orbit)*val
            rows.append({
                "alternative_graph":g,"orbit":sorted(orbit),"distance_cutoffs":[str(c) for c in cuts],
                "allowed_count_vectors_checked":len(choices),"weakest_count_vector":counts,
                "score_threshold":score,"false_positive_lower_per_rival":str(val),
            })
        passed = lower > EPS
        results.append({
            "shots":n,"distinct_rivals":sorted(covered),"rows":rows,
            "sum_false_positive_lower":str(lower),"sum_false_positive_lower_decimal":float(lower),
            "max_total_false_positive":"1/20","rules_out_shots":passed,
        })
        print(n,"sum >=" ,float(lower),"rules out",passed,flush=True)
    return {
        "null_graph":NULL,"continuous_weighted_B_upper":str(m),"necessary_total_weighted_B_lower":str(d),
        "cases":results,"necessary_N_integer":max((r["shots"] for r in results if r["rules_out_shots"]),default=0)+1,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("witness",type=Path)
    parser.add_argument("cases",type=Path)
    parser.add_argument("output",type=Path)
    args = parser.parse_args()
    data = json.loads(args.witness.read_text(encoding="utf-8"))
    cases = json.loads(args.cases.read_text(encoding="utf-8"))
    result = run(data,cases)
    args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")


if __name__ == "__main__":
    main()
