"""Exact shared-confusion Rényi certificate for continuous measurement time."""
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import permutations
import json
from math import ceil, isqrt
from pathlib import Path

from exact_topology_lower import BONDS, ROOT_SCALE, STATE_ERROR, STEPS, TIME_DEN, ceildiv, root_grid


P_FLIP = Fraction(1, 20)
SCALE = ROOT_SCALE
P_MIN = SCALE // 160000
ROOT_PAD = 1 + ceil(STATE_ERROR * SCALE)
CURVATURE_PAD = ceildiv(SCALE, TIME_DEN**2)


def lower_log(value):
    return sum(((1 - value)**n / n for n in range(1, 101)), Fraction())


def canonicalizer():
    maps = []
    for pi in permutations(range(4)):
        bits = [1 << BONDS.index(tuple(sorted((pi[a], pi[b])))) for a, b in BONDS]
        maps.append([sum(bits[k] for k in range(6) if g & (1 << k)) for g in range(64)] + [-1])
    rows = sorted({min(m[g] for m in maps) for g in range(64)})
    return rows, {(g, h): min((m[g], m[h]) for m in maps)
                  for g in range(64) for h in [*range(64), -1]}


def confusion_threshold(witness, terms):
    rows, canonical = canonicalizer()
    outcomes = witness["outcomes"]
    assert outcomes == sorted(set(outcomes) - {-1}) + [-1]
    active_rows = {canonical[g, -1][0] for a, b, _, _ in terms for g in (a, b)}
    assert all(g in outcomes for g in range(64) if canonical[g, -1][0] in active_rows)
    included_classes = {canonical[g, -1][0] for g in outcomes if g >= 0}
    assert all(g in outcomes for g in range(64) if canonical[g, -1][0] in included_classes)
    total = sum(w for _, _, _, w in terms)
    coeff = defaultdict(Fraction)
    log_part = Fraction()
    for (a, b, alpha, weight), z_s, tangents in zip(
            terms, witness["log_tangents"], witness["affinity_tangents"], strict=True):
        weight = Fraction(weight, total)
        z = Fraction(z_s)
        assert 0 < z < 1
        log_part += weight * (1 + lower_log(z))
        d, k = alpha.denominator, alpha.numerator
        for c, u_s in zip(outcomes, tangents, strict=True):
            u = Fraction(u_s)
            assert u > 0
            coeff[canonical[a, c]] += weight * alpha * u**(d-k) / z
            coeff[canonical[b, c]] += weight * (1-alpha) / (z*u**k)
    maximum = Fraction()
    for g in rows:
        if g not in active_rows:
            continue
        orbit_sizes = Counter(canonical[g, h] for h in outcomes)
        maximum += (1-P_FLIP) * coeff[g, g] + P_FLIP * max(
            coeff[key] / size for key, size in orbit_sizes.items())
    value = log_part - maximum
    return Fraction((10**12 * value).__floor__(), 10**12)


def floor_root(number, denominator):
    while denominator > 1:
        number = isqrt(number)
        denominator //= 2
    return number


def ceil_root(number, denominator):
    r = floor_root(number, denominator)
    return r + (r**denominator < number)


def probabilities(roots):
    return [(max(P_MIN, max(0, r - ROOT_PAD)**2 // SCALE),
             min(SCALE, ceildiv((r + ROOT_PAD)**2, SCALE))) for r in roots]


def affinity_at(p, q, d, k):
    return sum(floor_root(pl**k * ql**(d-k), d)
               for (pl, _), (ql, _) in zip(p, q, strict=True))


def interpolation_loss(p0, p1, q0, q1, d, k):
    # For the exact state with its global phase removed, ||psi'||=1 and
    # ||psi''||²=5/2+(49/400)sum(degree²)<=6.91. Therefore sum_x|P''(x)|<8
    # for any of the measured POVMs. Linear interpolation in a cell has L1
    # error at most h². This also bounds each coordinate's error by h².
    ratio_p = 0
    ratio_q = 0
    for p_l, p_r, q_l, q_r in zip(p0, p1, q0, q1, strict=True):
        pl = max(P_MIN, min(p_l[0], p_r[0]) - CURVATURE_PAD)
        pu = min(SCALE, max(p_l[1], p_r[1]) + CURVATURE_PAD)
        ql = max(P_MIN, min(q_l[0], q_r[0]) - CURVATURE_PAD)
        qu = min(SCALE, max(q_l[1], q_r[1]) + CURVATURE_PAD)
        ratio_p = max(ratio_p, ceildiv(qu, pl))
        ratio_q = max(ratio_q, ceildiv(pu, ql))
    # L∞ bounds on the two gradients, using the preceding coordinate boxes.
    lp = ceil_root(ceildiv(k**d * ratio_p**(d-k), d**d), d)
    lq = ceil_root(ceildiv((d-k)**d * ratio_q**k, d**d), d)
    return ceildiv((lp + lq) * SCALE, TIME_DEN**2)


def upper_log(affinity):
    x = SCALE - affinity
    assert 0 <= x < SCALE
    power = series = x
    for k in range(2, 13):
        power = ceildiv(power * x, SCALE)
        series += ceildiv(power, k)
    return series + ceildiv(power*x, 13*(SCALE-x))


def distance_upper(terms):
    graphs = sorted({g for a, b, _, _ in terms for g in (a, b)})
    probs = {}
    for g in graphs:
        probs[g] = [[probabilities(roots) for roots in settings]
                    for settings in root_grid(g, [P_FLIP])[P_FLIP]]
        print("enclosed grid", g, flush=True)
    start = [[0]*3 for _ in range(STEPS)]
    end = [[0]*3 for _ in range(STEPS)]
    for a, b, alpha, weight in terms:
        d, k = alpha.denominator, alpha.numerator
        p, q = probs[a], probs[b]
        for basis in range(3):
            grid = [affinity_at(p[t][basis], q[t][basis], d, k) for t in range(STEPS+1)]
            for t in range(STEPS):
                pad = interpolation_loss(p[t][basis], p[t+1][basis], q[t][basis], q[t+1][basis], d, k)
                # Concavity of the affinity in the two distributions, then
                # convexity of -log, bound each continuous cell by the convex
                # interpolation of its two padded endpoint bounds.
                start[t][basis] += weight * upper_log(grid[t] - pad)
                end[t][basis] += weight * upper_log(grid[t+1] - pad)
        print("bounded term", a, b, str(alpha), flush=True)
    maximum = max(max(values) for values in [*start, *end])
    return Fraction(maximum, SCALE * sum(w for _, _, _, w in terms))


def freeze(candidate):
    tangent = []
    for (_, _, order, _), table in zip(candidate["terms"], candidate["p_table"], strict=True):
        d = Fraction(order).denominator
        tangent.append([str(Fraction(f"{(b/a)**(1/d):.12g}")) for a, b in table])
    return {
        "terms": candidate["terms"],
        "outcomes": candidate["outcomes"],
        "affinity_tangents": tangent,
        "log_tangents": [str(Fraction(f"{x:.12g}")) for x in candidate["affinities"]],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--freeze", action="store_true")
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding="utf-8"))
    if args.freeze:
        result = freeze(data)
    else:
        terms = [(a, b, Fraction(order), w) for a, b, order, w in data["terms"]]
        assert all(w > 0 and 0 <= a < b < 64 and 0 < alpha < 1
                   and alpha.denominator in (2, 4, 8, 16) for a, b, alpha, w in terms)
        threshold = confusion_threshold(data, terms)
        print("confusion threshold", float(threshold), flush=True)
        distance = distance_upper(terms)
        ratio = threshold / distance
        result = {
            "threshold_lower": str(threshold),
            "distance_upper": str(distance),
            "ratio_floor_6": (10**6 * ratio).__floor__(),
            "necessary_n": ceil(ratio),
        }
        print(result, "ratio", float(ratio), flush=True)
    args.output.write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")


if __name__ == "__main__":
    main()
