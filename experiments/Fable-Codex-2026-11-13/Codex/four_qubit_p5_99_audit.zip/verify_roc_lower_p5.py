"""Rigorous p=.05 shot converse combining shared confusion and binary ROC domination."""
import argparse
from bisect import bisect_right
from fractions import Fraction as F
import json
from math import isqrt
from pathlib import Path

import numpy as np

from exact_topology_lower import ROOT_SCALE, STATE_ERROR, STEPS, TIME_DEN, root_grid
from verify_joint_confusion_lower import log_threshold_lower, site_maps

P = F(1, 20)
EPS = F(1, 20)
RATIO_BASE = F(41, 40)
NULL = 31
ALTERNATIVE = 47
S = ROOT_SCALE
MASS_SCALE = 1 << 48
LIMB = 24
MASK = (1 << LIMB) - 1
LOG_TERMS = 14


def ceildiv(a, b):
    return -(-a // b)


def ceil_fraction(a):
    return ceildiv(a.numerator, a.denominator)


def node_laws(graph):
    """Lower endpoint laws accounting for state error and t interpolation."""
    roots = root_grid(graph, [P])[P]
    re = ceil_fraction(STATE_ERROR * S)
    # For every outcome |p''| < 8. Interpolation error on a width-h
    # interval is therefore <= h^2. Subtract it at both endpoints.
    pad = ceildiv(S, TIME_DEN**2)
    vals = []
    for time in roots:
        vals.append(tuple(tuple(max(0, r - re)**2 // S - pad for r in basis) for basis in time))
    assert all(v > 0 for time in vals for basis in time for v in basis)
    return vals


def distance_ticks(p, q):
    # Sum of isqrt values is a lower affinity even for subprobability laws.
    x = S - sum(isqrt(a*b) for a,b in zip(p, q, strict=True))
    assert 0 <= x < S
    power = total = x
    for k in range(2, LOG_TERMS + 1):
        power = ceildiv(power*x, S)
        total += ceildiv(power, k)
    return total + ceildiv(power*x, (LOG_TERMS+1)*(S-x))


def weighted_envelopes(pairs, laws):
    out = []
    for i in range(STEPS + 1):
        out.append(tuple(
            sum(w * distance_ticks(laws[a][i][b], laws[c][i][b]) for a,c,w in pairs)
            for b in range(3)
        ))
    return out


def roc_hull(nodes, laws0, laws1):
    """Upper concave hull of exactly represented endpoint ROC vertices."""
    points = {0: 0, S: S}
    for i, b in nodes:
        n, a = laws0[i][b], laws1[i][b]
        ordered = sorted(zip(n, a, strict=True), key=lambda row: F(row[1], row[0]), reverse=True)
        x, y = 0, S-sum(a)
        points[x] = max(points.get(x, 0), y)
        for dx,dy in ordered:
            x += dx
            y += dy
            points[x] = max(points.get(x, 0), y)
    hull = []
    for x,y in sorted(points.items()):
        while len(hull) > 1:
            u,v = hull[-2]
            j,k = hull[-1]
            if (k-v)*(x-j) > (y-k)*(j-u):
                break
            hull.pop()
        hull.append((x,y))
    assert hull[0][0] == 0 and hull[-1] == (S,S)
    return hull


def quantized_laws(hull):
    """More informative finite likelihood-ratio law on a geometric grid."""
    segments = []
    null_pure = 0
    for (x,y),(u,v) in zip(hull, hull[1:]):
        dx, dy = u-x, v-y
        assert dx > 0 and dy >= 0
        if dy:
            segments.append((dx,dy,F(dy,dx)))
        else:
            null_pure += dx
    min_ratio = min(row[2] for row in segments)
    max_ratio = max(row[2] for row in segments)
    k = 0
    while RATIO_BASE**k > min_ratio:
        k -= 1
    low = k
    ratios = [RATIO_BASE**low]
    while ratios[-1] <= max_ratio:
        ratios.append(ratios[-1] * RATIO_BASE)
    p = [F(0) for _ in ratios]
    for dx,dy,r in segments:
        i = bisect_right(ratios, r) - 1
        lo,hi = ratios[i:i+2]
        at_hi = F(dy,S)/(hi-lo) - lo*F(dx,S)/(hi-lo)
        assert 0 <= at_hi <= F(dx,S)
        p[i] += F(dx,S)-at_hi
        p[i+1] += at_hi
    q = [x*y for x,y in zip(p,ratios,strict=True)]
    assert sum(p) + F(null_pure,S) == 1
    assert sum(q) + F(hull[0][1],S) == 1
    return low, p, q


def lower_convolution(schedules, side):
    mass = np.array([MASS_SCALE], dtype=np.uint64)
    origin = 0
    for experiment, shots in schedules:
        start, p, q = experiment
        law = (p,q)[side]
        increments = [(i,(x*MASS_SCALE).__floor__()) for i,x in enumerate(law) if x]
        assert sum(w for _,w in increments) <= MASS_SCALE
        for _ in range(shots):
            next_mass = np.zeros(len(mass) + len(law)-1, dtype=np.uint64)
            hi,lo = mass >> LIMB, mass & MASK
            for off,coef in increments:
                ch,cl = coef >> LIMB, coef & MASK
                cross = hi*cl + lo*ch + ((lo*cl) >> LIMB)
                next_mass[off:off+len(mass)] += hi*ch + (cross >> LIMB)
            mass = next_mass
        origin += shots * start
    assert int(mass.sum(dtype=np.uint64)) <= MASS_SCALE
    return origin, mass


def power_upper(schedules, size):
    origin, p = lower_convolution(schedules, 0)
    org_alt, q = lower_convolution(schedules, 1)
    assert origin == org_alt and len(p) == len(q)
    cdf_null = np.cumsum(p,dtype=np.uint64)
    cdf_alt = np.cumsum(q,dtype=np.uint64)
    total = int(cdf_null[-1])
    target = total - (size*MASS_SCALE).__floor__()
    center = int(np.searchsorted(cdf_null, max(0,target)))
    cuts = range(max(0,center-6),min(len(p),center+7))
    options = []
    for k in cuts:
        null_tail_lower = F(total-int(cdf_null[k]), MASS_SCALE)
        alt_tail_upper = 1-F(int(cdf_alt[k]), MASS_SCALE)
        ratio = RATIO_BASE ** (origin+k)
        options.append((alt_tail_upper + ratio*(size-null_tail_lower), origin+k, null_tail_lower, alt_tail_upper))
    return min(options)


def fraction_floor(x, scale):
    return F((x*scale).__floor__(), scale)


def run(witness, cases):
    selected = witness["pair_weights"]
    tangents = [F(v) for v in witness["log_tangents"]]
    affinities = [[F(v) for v in row] for row in witness["affinity_tangents"]]
    d = fraction_floor(log_threshold_lower(selected,tangents,affinities),10**15)
    degrees = {m[ALTERNATIVE] for m in site_maps() if m[NULL] == NULL}
    size = EPS / len(degrees)
    graphs = sorted({NULL,ALTERNATIVE}|{g for a,b,_ in selected for g in (a,b)})
    laws = {}
    for g in graphs:
        laws[g] = node_laws(g)
        print("endpoint laws",g,flush=True)
    enveloped = weighted_envelopes(selected,laws)
    denom = S * sum(w for _,_,w in selected)
    maximum = F(max(max(v) for v in enveloped), denom)
    print("continuous weighted B upper", float(maximum), "necessary weighted B", float(d), flush=True)
    nodes = {(i,b) for i in range(STEPS+1) for b in range(3)}
    all_hull = roc_hull(nodes,laws[NULL],laws[ALTERNATIVE])
    all_law = quantized_laws(all_hull)
    good_cache = {}
    rows = []
    for n,cutoff in cases:
        assert 0 < cutoff < maximum
        bad = ((n*maximum-d)/(maximum-cutoff)).__floor__()
        if bad < 0:
            rows.append({"shots":n,"weighted_B_alone_rules_out":True})
            continue
        bad = min(n,bad)
        if cutoff not in good_cache:
            good_nodes = {
                (j,b) for i in range(STEPS) for b in range(3)
                if max(enveloped[i][b],enveloped[i+1][b]) >= denom*cutoff
                for j in (i,i+1)
            }
            assert good_nodes
            hull = roc_hull(good_nodes,laws[NULL],laws[ALTERNATIVE])
            good_cache[cutoff] = quantized_laws(hull), len(good_nodes), len(hull)
        good_law, nn, hv = good_cache[cutoff]
        upper, score, qtail, ptail = power_upper(((good_law,n-bad),(all_law,bad)),size)
        row = {
            "shots":n,"weighted_B_cutoff":str(cutoff),"max_bad_shots":bad,
            "good_grid_nodes":nn,"good_roc_vertices":hv,"all_roc_vertices":len(all_hull),
            "test_size_upper":str(size),"test_power_required":str(1-EPS),
            "score_threshold":score,"null_upper_score_tail_lower":str(qtail),
            "alternative_upper_score_tail_upper":str(ptail),
            "test_power_upper":str(upper),
            "test_power_upper_decimal":float(upper),"rules_out_shots":upper < 1-EPS,
        }
        rows.append(row)
        print(n, str(cutoff), bad, nn, row["test_power_upper_decimal"], row["rules_out_shots"], flush=True)
    ruled_out = [
        row["shots"] for row in rows if row.get("rules_out_shots") or row.get("weighted_B_alone_rules_out")
    ]
    return {
        "null_graph":NULL,"alternative_graph":ALTERNATIVE,
        "stabilizer_rivals":sorted(degrees),"ratio_base":str(RATIO_BASE),
        "continuous_weighted_B_upper":str(maximum),"necessary_total_weighted_B_lower":str(d),
        "cases":rows,"necessary_N_integer":max(ruled_out,default=0)+1,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("witness",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("case",nargs="+",help="N:cutoff (cutoff may be a decimal or fraction)")
    args = parser.parse_args()
    cases = [(int(n),F(c)) for n,c in (v.split(":") for v in args.case)]
    witness = json.loads(args.witness.read_text(encoding="utf-8"))
    result = run(witness,cases)
    args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")


if __name__ == "__main__":
    main()
