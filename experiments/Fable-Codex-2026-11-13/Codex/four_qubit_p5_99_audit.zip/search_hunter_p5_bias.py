"""Find a 100-shot score table using Hunter forest improvements as a search proxy."""
import argparse
import json
from pathlib import Path

import numpy as np

import finite_shot_topology as model
from certify_hunter_p5 import coarsen
from certify_p5_integer_design import probability_lower
from search_nearby_p5_times import BiasScreen


def observe(g, p, rounded, shots, trials, rng):
    out = np.empty((trials,64), dtype=np.int16)
    for start in range(0,trials,20000):
        end = min(start+20000,trials)
        chunk = np.zeros((end-start,64))
        for k,n in enumerate(shots):
            counts = rng.multinomial(n,p[g,k],size=end-start).astype(float)
            chunk += counts @ rounded[:,k,:].T.astype(float)
        assert np.max(np.abs(chunk)) < 32768
        out[start:end] = chunk
    return out


def empirical_tree(observed, thresholds, g):
    events = observed >= thresholds
    counts = events.sum(axis=0)
    counts[g]=0
    useful=np.flatnonzero(counts)
    hits=events[:,useful].astype(float)
    joint=hits.T @ hits
    edges=[]
    for i,h in enumerate(useful):
        for j in range(i+1,len(useful)):
            if joint[i,j]:
                edges.append((int(joint[i,j]),int(h),int(useful[j])))
    comp=list(range(64))
    chosen=[]
    correction=0
    for count,a,b in sorted(edges,reverse=True):
        if comp[a]==comp[b]:
            continue
        chosen.append(dict(rival1=a,rival2=b))
        correction += count
        x,y=comp[a],comp[b]
        comp=[x if c==y else c for c in comp]
    return correction / len(observed), chosen


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("forest",type=Path)
    parser.add_argument("--trials",type=int,default=250000)
    parser.add_argument("--block",type=int,default=4)
    args=parser.parse_args()
    candidate=json.loads(args.candidate.read_text(encoding="utf-8"))
    design=candidate["design"]
    p=model.setting_probs([(b,t) for b,t,_ in design],.05)
    p/=p.sum(axis=2,keepdims=True)
    times=tuple(t for _,t,_ in design)
    shots=tuple(n for _,_,n in design)
    score=np.array(candidate["integer_scores"])
    screen=BiasScreen(candidate["log_rounding_scale"])
    reps,classes=screen.reps,screen.classes
    rng=np.random.default_rng(2026111323)
    obs={}
    probabilities={}
    for g in map(int,reps):
        probs=[probability_lower(g,b,t) for b,t,_ in design]
        probabilities[g]=probs
        rounded=np.array([coarsen(s-score[g],probs,shots,0,args.block)[0] for s in score])
        obs[g]=observe(g,p,rounded,shots,args.trials,rng)
    best=None
    best_proxy=1.
    for it in range(8):
        bias=np.array(candidate["integer_bias"])
        credit=[]
        forest={}
        for g in map(int,reps):
            probs=probabilities[g]
            thresh=np.array([coarsen(s-score[g],probs,shots,int(bias[g]-bias[h]),args.block)[1]
                             for h,s in enumerate(score)])
            x,edges=empirical_tree(obs[g],thresh,g)
            credit.append(x)
            forest[g]=edges
        credit=np.array(credit)
        proxy=max(np.array(candidate["approximate_pair_sums"])-credit)
        print("proxy",it,proxy,credit.tolist(),flush=True)
        if proxy<best_proxy:
            best_proxy=proxy
            best=candidate
            args.output.write_text(json.dumps(best),encoding="utf-8")
            args.forest.write_text(json.dumps({"forest":forest}),encoding="utf-8")
        candidate,_=screen.test(times,shots,bias[reps],credit)


if __name__=="__main__":
    main()
