"""Screen integer decoders with simulated Hunter-forest corrections."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize

import finite_shot_topology as model
from certify_hunter_p5 import coarsen
from certify_p5_integer_design import probability_lower
from search_hunter_p5_bias import empirical_tree
from search_p5_integer_design import graph_symmetry, tails_for_all_pairs, MinimizeWorstPairSum


REPS, CLASSES, PAIRS = graph_symmetry()


class Candidate:
    def __init__(self, times, shots, scales, biases, n, seed, block):
        self.design = [["Z", t, s] for t, s in zip(times, shots, strict=True)]
        self.shots = shots
        self.scales = scales
        self.probs = model.setting_probs([(b, t) for b, t, _ in self.design], .05)
        self.probs /= self.probs.sum(axis=2, keepdims=True)
        self.score = np.rint(np.log(self.probs) * np.asarray(scales)[None, :, None]).astype(int)
        rec = tails_for_all_pairs(self.score, self.probs, shots, CLASSES, PAIRS)
        self.obj = MinimizeWorstPairSum(rec, len(REPS), int(max(scales) * 4))
        rng = np.random.default_rng(seed)
        self.observed = []
        self.shift = []
        self.block = block
        for g in REPS:
            # The coarsening shifts do not depend on additive graph biases.
            delta = self.score - self.score[g]
            if block == 1:
                rounded = delta
                shift = np.zeros(64, dtype=int)
            else:
                probs = [probability_lower(int(g), basis, t) for basis, t, _ in self.design]
                pairs = [coarsen(d, probs, shots, 0, block) for d in delta]
                rounded = np.array([r[0] for r in pairs])
                # At exact integer threshold k*block, the residual offset is
                # recovered below for arbitrary integer graph biases.
                shift = np.array([sum(num * min(range(block), key=lambda s:
                    sum(((int(v)-s) % block)*q for v,q in zip(values,ps,strict=True)))
                    for num, values, ps in zip(shots, d, probs, strict=True)) for d in delta])
            observed = np.zeros((n, 64), dtype=np.int32)
            for k, count in enumerate(shots):
                samples = rng.multinomial(count, self.probs[g, k], size=n)
                for start in range(0,n,25000):
                    end = min(start+25000,n)
                    observed[start:end] += (samples[start:end].astype(float) @ rounded[:, k].T.astype(float)).astype(np.int32)
            self.observed.append(observed)
            self.shift.append(shift)
        self.biases = np.rint(biases).astype(int)
        self.biases -= self.biases[0]

    def eval(self, weights):
        w = weights[CLASSES]
        credit, actual, forest = [], [], {}
        for i, g in enumerate(REPS):
            threshold = (w[g] - w - self.shift[i] + self.block - 1) // self.block
            c, edges = empirical_tree(self.observed[i], threshold, int(g))
            hit = self.observed[i] >= threshold
            hit[:, g] = False
            actual.append(hit.any(axis=1).mean())
            credit.append(c)
            forest[str(g)] = edges
        credit = np.asarray(credit)
        union = self.obj.values(weights)
        return (union-credit).max(), union, credit, actual, forest

    def update(self, w0, credit):
        obj = self.obj
        rows, true, rival, mult = obj.rows, obj.true, obj.rival, obj.multiplicities
        zero, dim = 2*obj.bound, len(REPS)
        signs = np.zeros((len(rows), dim))
        signs[rows, true] = 1
        signs[rows, rival] -= 1

        def f(x, jac=False):
            w = np.r_[0, x[1:]]
            offset = (w[true] - w[rival] + zero).clip(0, 2*zero-1e-8)
            lo = np.floor(offset).astype(int)
            step = obj.tail[rows, lo+1] - obj.tail[rows, lo]
            if not jac:
                ev = mult * (obj.tail[rows, lo] + step * (offset-lo))
                return x[0] - np.bincount(true, weights=ev, minlength=dim) + credit
            partial = -(mult*step)[:,None] * signs[:,1:]
            j = np.zeros((dim,dim))
            j[:,0] = 1.
            np.add.at(j[:,1:],true,partial)
            return j

        sol = minimize(lambda x:x[0],np.r_[.07,w0[1:]],jac=lambda x:np.r_[1.,np.zeros(dim-1)],
                       method="SLSQP",constraints=[dict(type="ineq",fun=f,jac=lambda x:f(x,True))],
                       bounds=[(0.,.2)]+[(-obj.bound,obj.bound)]*(dim-1),
                       options={"maxiter":120,"ftol":1e-11})
        w = np.rint(np.r_[0.,sol.x[1:]]).astype(int)
        score = (obj.values(w)-credit).max()
        for _ in range(8):
            previous = score
            for j in range(1,dim):
                base = w[j]
                best = base
                for off in (-3,-2,-1,1,2,3):
                    trial = w.copy()
                    trial[j] = base+off
                    v = (obj.values(trial)-credit).max()
                    if v < score:
                        score,best = v,base+off
                w[j] = best
            if score >= previous:
                break
        return w

    def joint_update(self, w0, forest, radius=16):
        """Retune weights using overlap tails for a fixed sampled forest."""
        assert self.block == 1
        obj = self.obj
        rows, true, rival, mult = obj.rows, obj.true, obj.rival, obj.multiplicities
        zero, dim = 2 * obj.bound, len(REPS)
        signs = np.zeros((len(rows), dim))
        signs[rows, true] = 1
        signs[rows, rival] -= 1
        g_ids, h_ids, j_ids, tables, lo_h, lo_j = [], [], [], [], [], []
        n = self.observed[0].shape[0]
        side = 4 * radius + 2
        for i, g in enumerate(REPS):
            for edge in forest[str(g)]:
                h, j = edge["rival1"], edge["rival2"]
                k1, k2 = CLASSES[h], CLASSES[j]
                a, b = w0[i] - w0[k1] - 2*radius, w0[i] - w0[k2] - 2*radius
                x, y = self.observed[i][:, h], self.observed[i][:, j]
                keep = (x >= a) & (y >= b)
                ix = np.minimum(x[keep] - a, side - 1)
                iy = np.minimum(y[keep] - b, side - 1)
                hist = np.bincount(ix*side + iy, minlength=side**2).reshape(side, side)
                tails = hist[::-1, ::-1].cumsum(0).cumsum(1)[::-1, ::-1]
                g_ids.append(i)
                h_ids.append(k1)
                j_ids.append(k2)
                tables.append(tails / n)
                lo_h.append(a)
                lo_j.append(b)
        g, h, j, tables = map(np.asarray, (g_ids,h_ids,j_ids,tables))
        ei = np.arange(len(g))
        jac_a = np.zeros((len(g),dim))
        jac_b = np.zeros_like(jac_a)
        jac_a[ei,g] = jac_b[ei,g] = 1
        jac_a[ei,h] -= 1
        jac_b[ei,j] -= 1

        def model_at(w, jac=False):
            ua = (w[true] - w[rival] + zero).clip(0,2*zero-1e-8)
            ui = np.floor(ua).astype(int)
            du = mult * (obj.tail[rows, ui+1] - obj.tail[rows, ui])
            x = (w[g] - w[h] - lo_h).clip(0,side-1-1e-8)
            y = (w[g] - w[j] - lo_j).clip(0,side-1-1e-8)
            ix, iy = np.floor(x).astype(int), np.floor(y).astype(int)
            dx, dy = x-ix, y-iy
            a, b = tables[ei,ix,iy], tables[ei,ix+1,iy]
            c, d = tables[ei,ix,iy+1], tables[ei,ix+1,iy+1]
            if jac:
                gradient = np.zeros((dim,dim))
                np.add.at(gradient,true,du[:,None] * signs)
                dr = ((1-dy)*(b-a)+dy*(d-c))[:,None] * jac_a
                dc = ((1-dx)*(c-a)+dx*(d-b))[:,None] * jac_b
                np.add.at(gradient,g,-dr-dc)
                return gradient
            ub = mult*obj.tail[rows, ui] + du*(ua-ui)
            correction = (1-dx)*(1-dy)*a + dx*(1-dy)*b + (1-dx)*dy*c + dx*dy*d
            return (np.bincount(true,weights=ub,minlength=dim) -
                    np.bincount(g,weights=correction,minlength=dim))

        constraints = dict(type="ineq", fun=lambda x:x[0]-model_at(np.r_[0.,x[1:]]),
                           jac=lambda x:np.column_stack([np.ones(dim),-model_at(np.r_[0.,x[1:]],True)[:,1:]]))
        sol = minimize(lambda x:x[0],np.r_[model_at(w0).max()+.001,w0[1:]],
                       jac=lambda x:np.r_[1.,np.zeros(dim-1)],method="SLSQP",constraints=[constraints],
                       bounds=[(0.,.2)]+[(max(-obj.bound,w-radius),min(obj.bound,w+radius)) for w in w0[1:]],
                       options={"maxiter":150,"ftol":1e-12})
        w = np.rint(np.r_[0.,sol.x[1:]]).astype(int)
        best = model_at(w).max()
        if model_at(w0).max() < best:
            w = w0.copy()
            best = model_at(w).max()
        for _ in range(8):
            previous = best
            for k in range(1,dim):
                base = w[k]
                for inc in (-2,-1,1,2):
                    trial = w.copy()
                    trial[k] = base + inc
                    if abs(trial[k]-w0[k]) <= radius and model_at(trial).max() < best:
                        w = trial
                        best = model_at(w).max()
            if best >= previous:
                break
        return w

    def tune(self, rounds, joint=False):
        w = self.biases
        best = None
        for _ in range(rounds):
            proxy, union, credit, actual, forest = self.eval(w)
            if best is None or proxy < best[0]:
                result = dict(N=sum(self.shots),design=self.design,integer_scores=self.score.tolist(),
                              integer_bias=w[CLASSES].tolist(),log_rounding_scale=self.scales[0],
                              setting_rounding_scales=self.scales,approximate_pair_sums=union.tolist(),
                              representative_graphs=REPS.tolist(),proxy_error=float(proxy),
                              sampled_union_by_rep=actual,sampled_forest_credit=credit.tolist(),
                              sample_block=self.block)
                best = (proxy, result, {"forest":forest})
            next_w = self.joint_update(w,forest) if joint else self.update(w,credit)
            if np.array_equal(w, next_w):
                break
            w = next_w
        return best


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", type=Path, required=True)
    parser.add_argument("--n", type=int, default=99)
    parser.add_argument("--start", type=Path, default=Path("hunter_tuned_candidate_100.json"))
    parser.add_argument("--search", type=Path, help="JSON list of [first time, second time, second count, first scale, second scale]")
    parser.add_argument("--trials", type=int, default=80000)
    parser.add_argument("--seed", type=int, default=2026111324)
    parser.add_argument("--rounds", type=int, default=3)
    parser.add_argument("--block", type=int, default=1)
    parser.add_argument("--joint", action="store_true")
    args = parser.parse_args()
    previous = json.loads(args.start.read_text(encoding="utf-8"))
    prior = np.asarray(previous["integer_bias"])[REPS]
    prior_scale = previous["log_rounding_scale"]
    if args.search:
        proposals = json.loads(args.search.read_text(encoding="utf-8"))
    else:
        proposals = [(2.122,3.531,11,64,64),(2.122,3.531,10,64,64),
                     (2.104,3.531,11,64,64),(2.140,3.531,11,64,64),
                     (2.122,3.477,11,64,64),(2.122,3.585,11,64,64),
                     (2.122,3.531,12,64,64),(2.122,3.531,13,64,64),
                     (2.122,3.531,11,96,96),(2.122,3.531,11,128,128),
                     (2.122,3.531,11,48,48),(2.122,3.531,11,32,32)]
    history=[]
    for i,(a,b,c,s,t) in enumerate(proposals):
        trial = Candidate((a,b),(args.n-c,c),(s,t),prior*(s/prior_scale),args.trials,args.seed,args.block)
        proxy,result,forest = trial.tune(args.rounds,args.joint)
        print(i,(a,b,c,s,t),proxy,max(result["sampled_union_by_rep"]),flush=True)
        history.append((proxy,i))
        if (proxy,i) == min(history):
            for suffix,obj in (("candidate",result),("forest",forest)):
                Path(f"{args.prefix}_{suffix}_{i}.json").write_text(json.dumps(obj),encoding="utf-8")
    print(sorted(history),flush=True)


if __name__ == "__main__":
    main()
