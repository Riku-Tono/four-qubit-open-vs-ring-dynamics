"""Exact fixed-point lower bounds on intersections for a supplied Hunter forest.

Numerical tilts only choose which integer score cells to retain. The optional
saved box plans replay with integer operations. Discarding cells is always
downward, independent of the tilt or of any distributional approximation.
"""
import argparse
from collections import defaultdict
import json
from pathlib import Path

import numpy as np

from certify_hunter_p5 import coarsen, stabilizers
from certify_p5_integer_design import SCALE, graph_symmetry, probability_lower

MASS_BITS = 42
COEFF_BITS = 64 - MASS_BITS
MASS_SCALE = 1 << MASS_BITS
COEFF_SCALE = 1 << COEFF_BITS


def intersect_plan(delta, probabilities, shots, thresholds, sigma, taper, legacy_order=False):
    """Choose a reversible coordinate shear and a box for each shot."""
    from scipy.optimize import minimize
    from scipy.special import logsumexp

    log_p = np.log(np.maximum(probabilities, 1))
    log_p -= logsumexp(log_p, axis=1)[:, None]
    shots_np = np.array(shots, dtype=float)

    def moments(tilt):
        shifted = log_p + delta @ tilt
        z = logsumexp(shifted, axis=1)
        probs = np.exp(shifted - z[:, None])
        mean = np.einsum("ki,kij->kj", probs, delta)
        value = shots_np @ z - np.dot(tilt, thresholds)
        grad = shots_np @ mean - thresholds
        return value, grad, mean, probs

    result = minimize(lambda x: moments(x)[:2], np.zeros(2), jac=True,
                      bounds=[(0., 10.), (0., 10.)], method="L-BFGS-B")
    _, _, means, tilted = moments(result.x)
    centered = delta - means[:, None, :]
    cov = np.einsum("k,ki,kij,kil->jl", shots_np, tilted, centered, centered)
    x, shear = min(
        ((x, s) for x in (0, 1) for s in range(-3, 4)),
        key=lambda pair: (cov[pair[0], pair[0]] + 1) *
        (cov[1-pair[0], 1-pair[0]] + pair[1]**2 * cov[pair[0], pair[0]]
         - 2 * pair[1] * cov[pair[0], 1-pair[0]] + 1),
    )
    transformed = shear_vectors(delta, x, shear)
    t_mean = np.einsum("ki,kij->kj", tilted, transformed)
    t_var = np.einsum("ki,kij->kj", tilted, (transformed - t_mean[:, None, :])**2)
    total_var = shots_np @ t_var
    order = sorted(range(len(shots)), key=lambda i: shots[i] if legacy_order else
                   (t_var[i] / np.maximum(total_var, 1.)).sum())
    means = np.zeros(2)
    variances = np.zeros(2)
    boxes = []
    for k in order:
        for _ in range(shots[k]):
            means += t_mean[k]
            variances += t_var[k]
            remaining = np.maximum(1. - taper * variances / np.maximum(total_var, 1.), 0.)
            radius = sigma * np.sqrt(variances * remaining) + 12.
            low = np.floor(means - radius).astype(int)
            high = np.ceil(means + radius).astype(int) + 1
            boxes.append([int(low[0]), int(high[0]), int(low[1]), int(high[1])])
    return {"x": x, "shear": shear, "order": order, "boxes": boxes}


def shear_vectors(delta, x, shear):
    return np.stack((delta[..., x], delta[..., 1-x] - shear*delta[..., x]), axis=-1)


def rectangle_step(mass, origin, increments, box):
    x0, y0 = origin
    x1, y1 = x0 + mass.shape[0], y0 + mass.shape[1]
    minx = min(d[0] for d in increments)
    maxx = max(d[0] for d in increments)
    miny = min(d[1] for d in increments)
    maxy = max(d[1] for d in increments)
    a0, a1, b0, b1 = box
    a0, a1 = max(a0, x0 + minx), min(a1, x1 + maxx)
    b0, b1 = max(b0, y0 + miny), min(b1, y1 + maxy)
    out = np.zeros((max(a1-a0, 0), max(b1-b0, 0)), dtype=np.uint64)
    for (dx, dy), q in increments.items():
        xl, xh = max(a0, x0 + dx), min(a1, x1 + dx)
        yl, yh = max(b0, y0 + dy), min(b1, y1 + dy)
        if xl < xh and yl < yh:
            src = mass[xl-x0-dx:xh-x0-dx, yl-y0-dy:yh-y0-dy]
            # mass <= 2**42 and q < 2**22, so uint64 cannot overflow.
            out[xl-a0:xh-a0, yl-b0:yh-b0] += (src*q) >> COEFF_BITS
    return out, (a0, b0)


def intersection_lower(delta, probabilities, shots, thresholds, plan):
    """Return a mass numerator with denominator 2**48."""
    x, shear = plan["x"], plan["shear"]
    assert x in (0, 1) and isinstance(shear, int) and abs(shear) <= 3
    assert len(plan["boxes"]) == sum(shots)
    assert all(len(box) == 4 and all(isinstance(n, int) for n in box) for box in plan["boxes"])
    # First coordinate is one score, second is the other minus shear times it.
    vec = shear_vectors(delta, x, shear)
    origin = (0, 0)
    mass = np.array([[MASS_SCALE]], dtype=np.uint64)
    boxes = iter(plan["boxes"])
    order = plan.get("order", sorted(range(len(shots)), key=lambda i: shots[i]))
    assert sorted(order) == list(range(len(shots)))
    for k in order:
        grouped = defaultdict(int)
        for (dx, dy), p in zip(vec[k], probabilities[k], strict=True):
            grouped[int(dx), int(dy)] += int(p)
        coeff = {d: p >> (48-COEFF_BITS) for d, p in grouped.items()
                 if p >> (48-COEFF_BITS)}
        assert coeff and sum(coeff.values()) <= COEFF_SCALE
        assert all(0 < q < COEFF_SCALE for q in coeff.values())
        for _ in range(shots[k]):
            mass, origin = rectangle_step(mass, origin, coeff, next(boxes))
            if not mass.size:
                return 0
    assert int(mass.sum(dtype=np.uint64)) <= MASS_SCALE
    t1, t2 = int(thresholds[x]), int(thresholds[1-x])
    a, b = origin
    lower = 0
    for i in range(max(t1-a, 0), mass.shape[0]):
        start = max(t2 - shear*(a+i) - b, 0)
        lower += int(mass[i, start:].sum(dtype=np.uint64))
    return lower << (48-MASS_BITS)


def verify_forest(candidate, union, forest, block, sigma, graphs, plan_input, taper, checkpoint):
    for field in ("design", "integer_scores", "integer_bias"):
        assert candidate[field] == union[field]
    assert union["denominator"] == SCALE
    design = candidate["design"]
    shots = [n for _, _, n in design]
    scores = np.array(candidate["integer_scores"], dtype=np.int64)
    bias = np.array(candidate["integer_bias"], dtype=np.int64)
    assert scores.shape == (64, len(design), 16) and bias.shape == (64,)
    assert sum(shots) == candidate["N"] and sum(shots) > 0
    assert all(isinstance(n, int) and n >= 0 for n in shots)
    assert int(np.abs(scores).max()) < (1 << 15) and int(np.abs(bias).max()) < (1 << 15)
    reps, classes, _ = graph_symmetry(scores, bias)
    assert graphs is None or set(graphs) <= set(reps)
    sym = stabilizers(reps)
    output_forest = {}
    output_plans = {}
    after = {}
    used_blocks = {}

    def result():
        return dict(denominator=SCALE, blocks=used_blocks, representative_upper_numerators=after,
                    graph_upper_numerators=[after.get(str(int(reps[classes[g]]))) for g in range(64)],
                    forest=output_forest, plans=output_plans, worst_numerator=max(after.values()),
                    certifies_all_64_at_95=len(after)==len(reps) and 20*max(after.values())<=SCALE)

    for g in map(int, reps):
        if graphs is not None and g not in graphs:
            continue
        graph_block = block[str(g)] if isinstance(block, dict) else block
        assert isinstance(graph_block, int) and graph_block > 0
        used_blocks[str(g)] = graph_block
        upper = union["representative_upper_numerators"][str(g)]
        after[str(g)] = upper
        output_forest[str(g)] = []
        output_plans[str(g)] = {}
        if 20*upper <= SCALE:
            checkpoint(result())
            continue
        probs = [probability_lower(g, b, t) for b, t, _ in design]
        roundings = {}
        component = list(range(64))
        cache = {}
        for row in forest[str(g)]:
            h, j = row["rival1"], row["rival2"]
            assert h != g and j != g and 0 <= h < 64 and 0 <= j < 64
            assert component[h] != component[j], "not a forest"
            k1, k2 = min(tuple(sorted((m[h], m[j]))) for m in sym[g])
            edge_block = row.get("block", graph_block)
            assert isinstance(edge_block, int) and edge_block > 0
            key = f"{k1},{k2}" if edge_block == graph_block else f"{edge_block}:{k1},{k2}"
            if key not in cache:
                if edge_block not in roundings:
                    roundings[edge_block] = [
                        coarsen(scores[h]-scores[g], probs, shots, int(bias[g]-bias[h]), edge_block)
                        for h in range(64)
                    ]
                d1, t1 = roundings[edge_block][k1]
                d2, t2 = roundings[edge_block][k2]
                d = np.stack([d1, d2], axis=-1)
                plan = (intersect_plan(d, probs, shots, [t1,t2], sigma, taper)
                        if plan_input is None else plan_input[str(g)][key])
                cache[key] = intersection_lower(d, probs, shots, [t1,t2], plan)
                output_plans[str(g)][key] = plan
            lower = cache[key]
            if not lower:
                continue
            a, b = component[h], component[j]
            component = [a if c == b else c for c in component]
            edge = dict(rival1=h,rival2=j,intersection_lower_numerator=lower)
            if edge_block != graph_block:
                edge["block"] = edge_block
            output_forest[str(g)].append(edge)
            upper -= lower
            after[str(g)] = upper
            print(g, h, j, lower/SCALE, upper/SCALE, flush=True)
            if 20*upper <= SCALE and plan_input is None:
                break
        checkpoint(result())
    return result()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--union", type=Path, required=True)
    parser.add_argument("--forest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--block", type=int, default=2)
    parser.add_argument("--sigma", type=float, default=4.)
    parser.add_argument("--taper", type=float, default=0., help="Reduce retained window near the tilted endpoint")
    parser.add_argument("--graphs", nargs="+", type=int)
    parser.add_argument("--replay", action="store_true", help="Use integer plans stored in the supplied forest file")
    args = parser.parse_args()
    candidate = json.loads(args.candidate.read_text(encoding="utf-8"))
    union = json.loads(args.union.read_text(encoding="utf-8"))
    forest = json.loads(args.forest.read_text(encoding="utf-8"))
    assert args.block > 0
    assert 0 <= args.taper < 1
    block = forest.get("blocks", forest.get("block")) if args.replay else args.block

    def write(result):
        temporary = args.output.with_suffix(args.output.suffix+".tmp")
        temporary.write_text(json.dumps(result,separators=(",",":"))+"\n",encoding="utf-8")
        temporary.replace(args.output)

    result = verify_forest(candidate, union, forest["forest"], block, args.sigma,
                           args.graphs, forest["plans"] if args.replay else None, args.taper, write)
    print("worst",result["worst_numerator"]/SCALE,flush=True)


if __name__ == "__main__":
    main()
