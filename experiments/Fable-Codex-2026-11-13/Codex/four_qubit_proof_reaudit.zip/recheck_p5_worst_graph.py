"""Recheck the worst graph of the 104-shot certificate without grouping rivals."""
import argparse
from fractions import Fraction
import json
from pathlib import Path

import numpy as np

from audit_upper_independent import BONDS, MASS_SCALE, decimal_bound, lower_convolution, probability_enclosures


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("certificate", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    witness = json.loads(args.certificate.read_text(encoding="utf-8"), parse_float=Fraction)
    old = witness["graph_upper_numerators"]
    graph = old.index(max(old))
    p = Fraction(witness["p_flip"])
    scores = witness["integer_scores"]
    bias = witness["integer_bias"]
    design = witness["design"]
    bonds = {bond: Fraction(1) for i, bond in enumerate(BONDS) if graph & (1 << i)}
    prob = [probability_enclosures(bonds, b, t, p)[0] for b, t, _ in design]
    pair_uppers = {}
    for rival in range(64):
        if rival == graph:
            continue
        settings = [
            (n, q, [a - b for a, b in zip(scores[rival][i], scores[graph][i], strict=True)])
            for i, ((_, _, n), q) in enumerate(zip(design, prob, strict=True))
        ]
        mass, origin = lower_convolution(settings)
        threshold = bias[graph] - bias[rival]
        success_ticks = int(mass[:max(0, threshold - origin)].sum(dtype=np.uint64))
        pair_uppers[str(rival)] = MASS_SCALE - success_ticks
    assert len(pair_uppers) == 63
    upper = sum(pair_uppers.values())
    assert 20 * upper <= MASS_SCALE
    difference = Fraction(upper, MASS_SCALE) - Fraction(old[graph], witness["denominator"])
    result = {
        "true_graph": graph,
        "pair_error_upper_numerators": pair_uppers,
        "error_upper_numerator": upper,
        "denominator": MASS_SCALE,
        "error_upper_rounded_up": decimal_bound(upper, MASS_SCALE),
        "difference_from_first_implementation": str(difference),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(result["error_upper_rounded_up"])


if __name__ == "__main__":
    main()
