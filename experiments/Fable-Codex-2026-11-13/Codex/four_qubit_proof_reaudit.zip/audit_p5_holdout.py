"""Independently validate one fixed readout-5% measurement allocation."""
import argparse
import csv
import json
from pathlib import Path

from audit_mc import audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--design", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--trials", type=int, default=1_000_000)
    args = parser.parse_args()
    design = json.loads(args.design.read_text(encoding="utf-8"))
    rows = audit({0.05: (design,)}, "replay_multiple", args.trials, args.seed, exact_taylor=True)
    worst = None
    writer = None
    with args.output.open("w", encoding="utf-8-sig", newline="") as stream:
        for row in rows:
            if writer is None:
                writer = csv.DictWriter(stream, fieldnames=row.keys())
                writer.writeheader()
            writer.writerow(row)
            stream.flush()
            if worst is None or row["cp_simultaneous_lower_95"] < worst["cp_simultaneous_lower_95"]:
                worst = row
    print(json.dumps(worst, ensure_ascii=False, default=int), flush=True)


if __name__ == "__main__":
    main()
