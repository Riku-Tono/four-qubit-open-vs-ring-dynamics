"""Certify a fixed design's 64-way union bound with integer arithmetic."""
import argparse
from decimal import Decimal
from fractions import Fraction
from functools import lru_cache
from itertools import combinations
import json
import math
from pathlib import Path

PAIRS = tuple(combinations(range(4), 2))
OUTCOMES = range(16)
GRAPH_IDS = range(64)
K = 100
SCALE = 10**30

# ||tH||_2 <= (2 + 6 * 0.35) * 3.688 < 16.
TAIL = Fraction(16 ** (K + 1), math.factorial(K + 1)) / (
    1 - Fraction(16, K + 2)
)
assert TAIL < Fraction(1, SCALE * 100)
# For each outcome, the readout-adjusted sqrt probability is the norm
# of the vector of measurement amplitudes weighted by sqrt(readout rate).
# Its vector error across outcomes is <= TAIL. Thus an affinity differs
# from its Taylor-state counterpart by at most (2+TAIL)*TAIL < 1/SCALE.
assert (2 + TAIL) * TAIL < Fraction(1, SCALE)


def state_numerators(graph_id, time):
    """Taylor state with a single integer denominator."""
    tau = Fraction(str(time)) / 20
    diagonal = [
        7 * sum(
            (-1) ** ((x >> (3 - i) ^ x >> (3 - j)) & 1)
            for k, (i, j) in enumerate(PAIRS)
            if graph_id & (1 << k)
        )
        for x in OUTCOMES
    ]
    factorial = math.factorial(K)
    real = [0] * 16
    imag = [0] * 16
    power = [1] + [0] * 15
    for k in range(K + 1):
        coefficient = (
            (factorial // math.factorial(k))
            * tau.numerator**k
            * tau.denominator ** (K - k)
        )
        if k % 4 in (1, 2):
            coefficient = -coefficient
        component = imag if k % 2 else real
        for x in OUTCOMES:
            component[x] += coefficient * power[x]
        if k < K:
            power = [
                diagonal[x] * power[x] + 10 * sum(power[x ^ bit] for bit in (1, 2, 4, 8))
                for x in OUTCOMES
            ]
    return real, imag, factorial * tau.denominator**K


def probabilities(graph_id, basis, time, p):
    """Exact readout probabilities for the Taylor state."""
    real, imag, denominator = state_numerators(graph_id, time)
    if basis in ("X", "Y"):
        if basis == "Y":
            for x in OUTCOMES:
                for _ in range(x.bit_count() % 4):
                    real[x], imag[x] = imag[x], -real[x]
        real = [sum((-1)**((x & y).bit_count() % 2) * real[y] for y in OUTCOMES) for x in OUTCOMES]
        imag = [sum((-1)**((x & y).bit_count() % 2) * imag[y] for y in OUTCOMES) for x in OUTCOMES]
        denominator *= 4
    else:
        assert basis == "Z"
    masses = [a * a + b * b for a, b in zip(real, imag, strict=True)]
    wrong = p.numerator
    right = p.denominator - wrong
    flip_weights = [wrong**d * right**(4 - d) for d in range(5)]
    adjusted = [
        sum(masses[y] * flip_weights[(x ^ y).bit_count()] for y in OUTCOMES)
        for x in OUTCOMES
    ]
    return adjusted, denominator**2 * p.denominator**4


@lru_cache(maxsize=30)
def upper_affinities(basis, time, p):
    probs = [probabilities(g, basis, time, p) for g in GRAPH_IDS]
    upper = []
    for i, j in combinations(GRAPH_IDS, 2):
        a, da = probs[i]
        b, db = probs[j]
        roots = sum(
            math.isqrt(x * y * SCALE**2 // (da * db))
            for x, y in zip(a, b, strict=True)
        )
        # 16 rounded roots, plus the Taylor error.
        upper.append(min(roots + 17, SCALE))
    return upper


def certify(settings, p):
    affinities = [upper_affinities(b, t, p) for b, t, _ in settings]
    allocation = [n for _, _, n in settings]
    shot_count = sum(allocation)
    denominator = SCALE**shot_count
    bounds = [0] * 64
    for k, (i, j) in enumerate(combinations(GRAPH_IDS, 2)):
        product = math.prod(affinities[s][k]**n for s, n in enumerate(allocation))
        bounds[i] += product
        bounds[j] += product
    worst = max(bounds)
    # Round upward to 12 decimal places for machine-readable reporting.
    rounded_up = (worst * 10**12 + denominator - 1) // denominator
    return {
        "shots": shot_count,
        "allocation": settings,
        "worst_graph_id": bounds.index(worst),
        "error_upper_rounded_up": str(Decimal(rounded_up).scaleb(-12)),
        "certifies_95_percent": 20 * worst <= denominator,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("designs", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    designs = json.loads(args.designs.read_text(encoding="utf-8"))
    results = {
        key: certify(value["allocation"], Fraction(str(value["p"])))
        for key, value in designs.items()
    }
    args.output.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
