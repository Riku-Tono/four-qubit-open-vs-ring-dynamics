"""Re-certify the 64-graph continuous-time lower bounds with integers only.

Run with Python 3.10+; this file has no numerical-library dependencies.
Candidate integer weights were chosen from the prior LP; their validity
does not depend on how they were chosen or on LP optimality.
"""
import argparse
from fractions import Fraction
from itertools import combinations
import json
from math import factorial, isqrt
from pathlib import Path


BONDS = tuple(combinations(range(4), 2))
DUALS = {
    Fraction(0): ((1, 33, 81416), (13, 37, 109213), (30, 45, 60833),
                  (31, 47, 165072), (31, 63, 583467)),
    Fraction(1, 50): ((0, 1, 154272), (31, 47, 400092), (31, 63, 445636)),
    Fraction(1, 20): ((0, 1, 240623), (11, 15, 30166), (31, 47, 729212)),
}
TIME_DEN = 1000
STEPS = 3688
TAYLOR_DEGREE = 5
STATE_SCALE = 2**64
ROOT_SCALE = 2**48
LOG_DEGREE = 12

# z >= ||H/1000||, since ||H|| <= 4*(1/2)+6*(7/20).
Z = Fraction(41, 10 * TIME_DEN)
REMAINDER = Z ** (TAYLOR_DEGREE + 1) / factorial(TAYLOR_DEGREE + 1) / (
    1 - Z / (TAYLOR_DEGREE + 2)
)
assert STEPS * REMAINDER < Fraction(1, 2)
# Componentwise downward rounding in the 32 real coordinates adds <6/S.
# ||P_step|| <= 1+REMAINDER. After j steps, the amplification is at most
# (1+REMAINDER)^j <= 1/(1-j*REMAINDER) <= 2.
STATE_ERROR = 2 * STEPS * (REMAINDER + Fraction(6, STATE_SCALE))
# 8 ticks cover the rounding of two length-16 square-root probability vectors.
# The final 1/TIME_DEN covers the distance to a nearest node at chord speed 2.
CHORD_EXTRA = 8 + (ROOT_SCALE * (2 * STATE_ERROR + Fraction(1, TIME_DEN))).__ceil__()

# Exact lower bound on D = -log(2*sqrt(.05*.95)) = -log(.19)/2.
D_LOWER = sum((Fraction(81, 100) ** k / (2 * k) for k in range(1, 97)), Fraction())


def ceildiv(a, b):
    return (a + b - 1) // b


def ceil_sqrt(n):
    r = isqrt(n)
    return r if r * r == n else r + 1


def propagator(graph):
    """Real and imaginary integer numerators of the single-step polynomial."""
    denominator = 20 * TIME_DEN
    common = denominator**TAYLOR_DEGREE * factorial(TAYLOR_DEGREE)
    diagonal = [
        7 * sum(
            (-1) ** (((x >> (3 - i)) ^ (x >> (3 - j))) & 1)
            for k, (i, j) in enumerate(BONDS)
            if graph & (1 << k)
        )
        for x in range(16)
    ]
    power = [[int(i == j) for j in range(16)] for i in range(16)]
    real = [[0] * 16 for _ in range(16)]
    imag = [[0] * 16 for _ in range(16)]
    for k in range(TAYLOR_DEGREE + 1):
        part = real if k % 2 == 0 else imag
        scale = common // (denominator**k * factorial(k))
        if k % 4 in (1, 2):
            scale = -scale
        for i in range(16):
            for j in range(16):
                part[i][j] += scale * power[i][j]
        if k < TAYLOR_DEGREE:
            power = [
                [diagonal[i] * power[i][j] + 10 * sum(power[i ^ b][j] for b in (1, 2, 4, 8))
                 for j in range(16)]
                for i in range(16)
            ]
    matrix = [tuple(zip(r, s, strict=True)) for r, s in zip(real, imag, strict=True)]
    return matrix, common


def advance(matrix, divisor, state):
    new_state = []
    for row in matrix:
        real = imag = 0
        for (a, b), (x, y) in zip(row, state, strict=True):
            real += a * x - b * y
            imag += a * y + b * x
        new_state.append((real // divisor, imag // divisor))
    return new_state


def walsh(values):
    out = list(values)
    for width in (1, 2, 4, 8):
        for offset in range(0, 16, 2 * width):
            for i in range(offset, offset + width):
                a, b = out[i], out[i + width]
                out[i], out[i + width] = a + b, a - b
    return out


def phase_y(state):
    out = []
    for x, (a, b) in enumerate(state):
        phase = x.bit_count() % 4
        out.append(((a, b), (b, -a), (-a, -b), (-b, a))[phase])
    return out


def measured_masses(state):
    """Squared amplitude numerators, all with denominator (4*STATE_SCALE)^2."""
    masses = []
    for entries in (state, phase_y(state)):
        a, b = zip(*entries, strict=True)
        masses.append([r*r + s*s for r, s in zip(walsh(a), walsh(b), strict=True)])
    masses.append([16 * (a*a + b*b) for a, b in state])
    return masses


def roots_on_basis(masses, p):
    wrong, den = p.numerator, p.denominator
    if wrong:
        right = den - wrong
        observed = list(masses)
        for bit in (1, 2, 4, 8):
            for index in range(16):
                if index & bit == 0:
                    a, b = observed[index], observed[index ^ bit]
                    observed[index] = right * a + wrong * b
                    observed[index ^ bit] = wrong * a + right * b
    else:
        observed = masses
    # ROOT_SCALE <= 4*STATE_SCALE and both are powers of two.
    divisor = ((4 * STATE_SCALE) // ROOT_SCALE)**2 * den**4
    return tuple(isqrt(m // divisor) for m in observed)


def root_grid(graph, rates):
    matrix, divisor = propagator(graph)
    state = [(STATE_SCALE, 0)] + [(0, 0)] * 15
    grids = {p: [] for p in rates}
    for step in range(STEPS + 1):
        masses = measured_masses(state)
        for p in rates:
            grids[p].append(tuple(roots_on_basis(row, p) for row in masses))
        if step < STEPS:
            state = advance(matrix, divisor, state)
    return grids


def distance_upper_ticks(a, b):
    chord = ceil_sqrt(sum((x-y)**2 for x, y in zip(a, b, strict=True))) + CHORD_EXTRA
    # B = -log(1 - chord^2/2). Bound with an upward-rounded positive
    # series and a geometric remainder, all in units of 1/ROOT_SCALE.
    x = ceildiv(chord**2, 2 * ROOT_SCALE)
    assert 0 <= x < ROOT_SCALE
    power = x
    series = x
    for k in range(2, LOG_DEGREE + 1):
        power = ceildiv(power * x, ROOT_SCALE)
        series += ceildiv(power, k)
    tail = ceildiv(power * x, (LOG_DEGREE + 1) * (ROOT_SCALE - x))
    return series + tail


def lower_results():
    graphs = sorted({g for pairs in DUALS.values() for a, b, _ in pairs for g in (a, b)})
    grids = {}
    for graph in graphs:
        rates = [p for p, pairs in DUALS.items() if any(graph in (a, b) for a, b, _ in pairs)]
        grids[graph] = root_grid(graph, rates)
        print(f"Calculated rationally enclosed nodes for graph {graph}.", flush=True)
    result = {}
    for p, pairs in DUALS.items():
        peak = 0
        node = basis = None
        for step in range(STEPS + 1):
            for i, b in enumerate("XYZ"):
                current = sum(
                    weight * distance_upper_ticks(grids[a][p][step][i], grids[c][p][step][i])
                    for a, c, weight in pairs
                )
                if current > peak:
                    peak, node, basis = current, step, b
        denominator = sum(w for _, _, w in pairs) * ROOT_SCALE
        necessary = D_LOWER * denominator / peak
        certified_minimum = necessary.__ceil__()
        result[str(p)] = {
            "dual_integer_weights": pairs,
            "maximum_weighted_B_upper": {"numerator": peak, "denominator": denominator},
            "maximum_envelope_node": {"time": str(Fraction(node, TIME_DEN)), "basis": basis},
            "necessary_N_floor_6_decimals": str(Fraction((necessary * 10**6).__floor__(), 10**6)),
            "necessary_N_integer": certified_minimum,
        }
        print(f"p={p} → N >= {certified_minimum}; real lower >= {float(necessary):.9f}", flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = {
        "time_grid": {"step": "1/1000", "points": STEPS + 1},
        "state_fixed_point_scale": STATE_SCALE,
        "state_error_upper": str(STATE_ERROR),
        "root_fixed_point_scale": ROOT_SCALE,
        "chord_envelope_padding_ticks": CHORD_EXTRA,
        "D_lower": str(D_LOWER),
        "topology": lower_results(),
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
