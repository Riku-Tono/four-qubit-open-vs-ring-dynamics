"""Certify a fixed integer-score decoder by downward integer convolution."""
import argparse
from fractions import Fraction
from itertools import permutations
import json
from pathlib import Path

import numpy as np

from verify_union_bound import PAIRS, TAIL, probabilities


SCALE = 1 << 48
LIMB_BITS = 24
LIMB_MASK = (1 << LIMB_BITS) - 1
P_FLIP = Fraction(1, 20)
PROBABILITY_ERROR = Fraction(1, 1 << 100)
assert (2 + TAIL) * TAIL < PROBABILITY_ERROR


def graph_symmetry(scores, bias):
    """The physical law and the supplied score table use the same site action."""
    graph_maps = []
    for permutation in permutations(range(4)):
        edge_map = [1 << PAIRS.index(tuple(sorted((permutation[i], permutation[j])))) for i, j in PAIRS]
        graph_map = [sum(edge_map[i] for i in range(6) if g & (1 << i)) for g in range(64)]
        outcome_map = [sum(1 << (3 - permutation[i]) for i in range(4) if x & (1 << (3 - i)))
                       for x in range(16)]
        assert np.array_equal(scores, scores[graph_map][:, :, outcome_map]), permutation
        assert np.array_equal(bias, bias[graph_map]), permutation
        graph_maps.append(graph_map)
    graph_maps = np.array(graph_maps)
    reps, classes = np.unique(graph_maps.min(axis=0), return_inverse=True)
    pairs = []
    for g in reps:
        stabilizer = graph_maps[graph_maps[:, g] == g]
        for h, m in zip(*np.unique(stabilizer.min(axis=0), return_counts=True)):
            if h != g:
                pairs.append((int(g), int(h), int(m)))
    return reps, classes, pairs


def probability_lower(graph, basis, time):
    nums, den = probabilities(graph, basis, time, P_FLIP)
    unit = PROBABILITY_ERROR.denominator
    return [max(0, ((num * unit - den) * SCALE) // (den * unit)) for num in nums]


def scaled_product(mass_hi, mass_lo, coefficient):
    """floor(mass*coefficient/2**48) with intermediates less than 2**50."""
    coef_hi = coefficient >> LIMB_BITS
    coef_lo = coefficient & LIMB_MASK
    cross = mass_hi * coef_lo + mass_lo * coef_hi
    low = ((cross & LIMB_MASK) << LIMB_BITS) + mass_lo * coef_lo
    return mass_hi * coef_hi + (cross >> LIMB_BITS) + (low >> (2 * LIMB_BITS))


def pair_failure_upper(differences, probability_masses, shots, threshold):
    """Upper bound on P(sum rival−true increments >= threshold), including ties."""
    order = np.argsort(np.ptp(differences, axis=1))
    mass = np.array([SCALE], dtype=np.uint64)
    origin = 0
    for index in order:
        if not shots[index]:
            continue
        groups = {}
        for value, probability in zip(differences[index], probability_masses[index], strict=True):
            value = int(value)
            groups[value] = groups.get(value, 0) + probability
        increments = sorted(groups)
        minimum = increments[0]
        width = increments[-1] - minimum
        assert sum(groups.values()) <= SCALE
        assert all(0 <= groups[value] < SCALE for value in increments)
        for _ in range(shots[index]):
            mass_hi = mass >> LIMB_BITS
            mass_lo = mass & LIMB_MASK
            next_mass = np.zeros(len(mass) + width, dtype=np.uint64)
            for value in increments:
                offset = value - minimum
                coefficient = groups[value]
                if coefficient:
                    next_mass[offset:offset + len(mass)] += scaled_product(mass_hi, mass_lo, coefficient)
            nonzero = np.flatnonzero(next_mass)
            if not len(nonzero):
                return SCALE
            origin += minimum + int(nonzero[0])
            mass = next_mass[nonzero[0]:nonzero[-1] + 1]
    boundary = max(0, threshold - origin)
    return SCALE - int(mass[:boundary].sum(dtype=np.uint64))


def check_scaled_product():
    values = [0, 1, LIMB_MASK, 1 << LIMB_BITS, SCALE - 1, SCALE]
    v = np.array(values, dtype=np.uint64)
    for c in values[:-1]:
        observed = scaled_product(v >> LIMB_BITS, v & LIMB_MASK, c).tolist()
        assert observed == [m * c // SCALE for m in values]


def certify(candidate):
    design = candidate["design"]
    scores = np.asarray(candidate["integer_scores"], dtype=np.int64)
    bias = np.asarray(candidate["integer_bias"], dtype=np.int64)
    shots = [n for _, _, n in design]
    assert scores.shape == (64, len(design), 16) and bias.shape == (64,)
    assert sum(shots) == candidate["N"] and all(isinstance(n, int) and n >= 0 for n in shots)
    assert int(np.abs(scores).max()) < (1 << 15) and int(np.abs(bias).max()) < (1 << 15)
    assert all(basis in ("X", "Y", "Z") and 0 <= Fraction(str(time)) <= Fraction("3.688")
               for basis, time, _ in design)
    reps, classes, pairs = graph_symmetry(scores, bias)
    probabilities_by_rep = {
        int(g): [probability_lower(int(g), basis, time) for basis, time, _ in design] for g in reps
    }
    totals = {int(g): 0 for g in reps}
    multiplicities = {int(g): 0 for g in reps}
    bounds = []
    for g, h, multiplicity in pairs:
        threshold = int(bias[g]) - int(bias[h])
        numerator = pair_failure_upper(scores[h] - scores[g], probabilities_by_rep[g], shots, threshold)
        totals[g] += numerator * multiplicity
        multiplicities[g] += multiplicity
        bounds.append({"true_graph": g, "rival_graph": h, "multiplicity": multiplicity,
                       "pair_failure_upper_numerator": numerator})
    assert all(n == 63 for n in multiplicities.values())
    worst = max(totals.values())
    by_graph = [totals[int(reps[classes[g]])] for g in range(64)]
    print(f"worst error <= {worst}/{SCALE} = {worst / SCALE:.12f}", flush=True)
    return dict(N=candidate["N"], p_flip=str(P_FLIP), design=design, integer_scores=candidate["integer_scores"],
                integer_bias=candidate["integer_bias"], denominator=SCALE, representative_upper_numerators=totals,
                graph_upper_numerators=by_graph, directed_pair_upper_bounds=bounds, worst_numerator=worst,
                tie_rule="accept unique maximum integer score; count every maximum tie as failure",
                certifies_all_64_at_95=(worst * 20 <= SCALE))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    check_scaled_product()
    candidate = json.loads(args.candidate.read_text(encoding="utf-8"))
    result = certify(candidate)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
