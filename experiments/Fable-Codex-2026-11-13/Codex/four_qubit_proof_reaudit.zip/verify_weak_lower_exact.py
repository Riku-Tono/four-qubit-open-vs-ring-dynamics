"""Independently check continuous weak-link lower witnesses using only integers.

Model: |0000>, H=1/2 sum X + 7/20 (Z01 + Z12 + Z23 + lambda Z03).
The previous JSON proposes a partition in lambda. None of its computed
probabilities, time enclosures or objective values is used in this check.
"""
import argparse
from fractions import Fraction
from functools import cache
import json
from math import factorial, isqrt, lcm
from pathlib import Path


TIME_MAX = Fraction(461, 125)
STRENGTH = Fraction(7, 20)
ORDER = 72
SCALE = 1 << 60
AFFINITY_SCALE = 1 << 96
GRAPHS = ((0, 1), (1, 2), (2, 3), (0, 3))
BITS = range(16)
POPCOUNT = tuple(x.bit_count() for x in BITS)
PAULI_ZZ = tuple(
    tuple(1 - 2 * (((x >> (3 - i)) ^ (x >> (3 - j))) & 1) for x in BITS)
    for i, j in GRAPHS
)
SCHEDULES = {
    (Fraction(0), 62): (("X", "2.272", 28), ("Z", "2.028", 7), ("Z", "2.376", 4),
                        ("Z", "3.176", 10), ("Z", "3.688", 13)),
    (Fraction(".02"), 80): (("Z", "2.112", 70), ("Z", "3.280", 10)),
    (Fraction(".05"), 106): (("X", "2.260", 5), ("Z", "2.104", 90), ("Z", "3.036", 11)),
    (Fraction(".05"), 105): (("X", "2.260", 5), ("Z", "2.104", 89), ("Z", "3.036", 11)),
}

# The symmetric absolute-row-sum bound on ||T_MAX H||_2 is
# T_MAX (2 + (7/20)*(3+lambda)) < 13 for all lambda in [0,1].
# Consequently the geometric bound on the operator-norm Taylor remainder is:
TAYLOR_TAIL = Fraction(13 ** (ORDER + 1), factorial(ORDER + 1)) / (
    1 - Fraction(13, ORDER + 2)
)
assert TIME_MAX * (2 + 4 * STRENGTH) < 13
assert TAYLOR_TAIL * SCALE < 1

# Each real/imaginary coordinate in the Horner evaluation has at most ORDER+1
# coefficient rounding errors and ORDER+1 Horner rounding errors, all <1/SCALE
# and with factors of magnitude <=1. An extra rounding handles the odd terms.
# sqrt(32) < 6 converts the coordinate bound to a state-vector norm bound.
STATE_ERROR = 6 * (2 * ORDER + 3) + 1
ROOT_VECTOR_ERROR = STATE_ERROR + 4


def ceil_fraction(x):
    return -(-x.numerator // x.denominator)


def ceil_isqrt(x):
    return isqrt(x - 1) + 1 if x else 0


def walsh(vector):
    """Integer Walsh-Hadamard transform, with the normalization left out."""
    result = list(vector)
    for step in (1, 2, 4, 8):
        for first in range(0, 16, 2 * step):
            for j in range(first, first + step):
                a, b = result[j], result[j + step]
                result[j], result[j + step] = a + b, a - b
    return result


def probabilities(real, imag, basis, p):
    """Mass numerators, with common denominator SCALE**2 times the returned factor."""
    factor = 1
    if basis == "Y":
        rotated = [(a, b) if c % 4 == 0 else (b, -a) if c % 4 == 1
                   else (-a, -b) if c % 4 == 2 else (-b, a)
                   for a, b, c in zip(real, imag, POPCOUNT, strict=True)]
        real, imag = zip(*rotated, strict=True)
    if basis in ("X", "Y"):
        real, imag = walsh(real), walsh(imag)
        factor = 16
    masses = [a * a + b * b for a, b in zip(real, imag, strict=True)]
    if p:
        error, correct = p.numerator, p.denominator - p.numerator
        for step in (1, 2, 4, 8):
            for first in range(0, 16, 2 * step):
                for j in range(first, first + step):
                    a, b = masses[j], masses[j + step]
                    masses[j] = correct * a + error * b
                    masses[j + step] = error * a + correct * b
        factor *= p.denominator**4
    return masses, factor


class IntegerState:
    def __init__(self, lam):
        assert 0 <= lam <= 1
        diag = [
            TIME_MAX * STRENGTH * sum(
                s[x] * c for s, c in zip(PAULI_ZZ, (1, 1, 1, lam), strict=True)
            )
            for x in BITS
        ]
        flip = TIME_MAX / 2
        den = lcm(flip.denominator, *(x.denominator for x in diag))
        diagonal = [int(x * den) for x in diag]
        off = int(flip * den)
        power = [1] + [0] * 15
        denominator = 1
        coeff = [[], []]
        for k in range(ORDER + 1):
            sign = -1 if k % 4 in (1, 2) else 1
            coeff[k % 2].append(tuple(sign * SCALE * v // denominator for v in power))
            if k < ORDER:
                power = [
                    diagonal[x] * power[x]
                    + off * (power[x ^ 1] + power[x ^ 2] + power[x ^ 4] + power[x ^ 8])
                    for x in BITS
                ]
                denominator *= den * (k + 1)
        self.even, self.odd = (tuple(reversed(c)) for c in coeff)

    def point(self, x):
        assert 0 <= x <= 1
        u, v = x.numerator, x.denominator
        u2, v2 = u * u, v * v
        if v & (v - 1):
            def evaluate(coeff):
                vector = coeff[0]
                for term in coeff[1:]:
                    vector = [a + (u2 * b) // v2 for a, b in zip(term, vector, strict=True)]
                return vector
        else:
            shift = v2.bit_length() - 1

            def evaluate(coeff):
                vector = coeff[0]
                for term in coeff[1:]:
                    vector = [a + ((u2 * b) >> shift) for a, b in zip(term, vector, strict=True)]
                return vector
        return evaluate(self.even), [a * u // v for a in evaluate(self.odd)]

    def roots(self, x, p, bases):
        state = self.point(x)
        out = []
        for basis in bases:
            mass, factor = probabilities(*state, basis, p)
            out.append(tuple(isqrt(m // factor) for m in mass))
        return tuple(out)


BASE = IntegerState(Fraction(0))


@cache
def base_roots(x, p, bases):
    return BASE.roots(x, p, bases)


def chords(model, x, p, bases):
    """Return integer upper bounds on SCALE times the Hellinger chords."""
    a, b = base_roots(x, p, bases), model.roots(x, p, bases)
    return tuple(
        ceil_isqrt(sum((v - w) ** 2 for v, w in zip(r, s, strict=True)))
        + 2 * ROOT_VECTOR_ERROR
        for r, s in zip(a, b, strict=True)
    )


def affinity_lower(chord):
    denominator = 2 * SCALE**2
    return max(0, AFFINITY_SCALE * (denominator - chord**2) // denominator)


def power_down(base, exponent):
    """Lower bound in AFFINITY_SCALE units with exact downward multiplication."""
    result = AFFINITY_SCALE
    while exponent:
        if exponent & 1:
            result = result * base // AFFINITY_SCALE
        base = base**2 // AFFINITY_SCALE
        exponent >>= 1
    return result


def proves_impossibility(product_squared):
    return 100 * product_squared > 19 * AFFINITY_SCALE


def chord_limit(n):
    """Largest scaled integer chord with certified BC**(2*n) > 19/100."""
    lo, hi = 0, SCALE
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if proves_impossibility(power_down(affinity_lower(mid), 2 * n)):
            lo = mid
        else:
            hi = mid
    return lo


def lambda_cells(witness):
    end = witness["impossible_through"]
    assert end > 0
    covered = Fraction(0)
    for a, b, *_ in witness["intervals"]:
        if not (a == covered and a < b <= end):
            raise ValueError("Invalid candidate lambda partition")
        yield a, b
        covered = b
    if covered != end:
        raise ValueError("Candidate partition does not cover the target")


def global_cell(p, a, b, limit):
    """Certify a whole rectangle lambda in [a,b], 0 <= t <= T_MAX."""
    model = IntegerState((a + b) / 2)
    radius = (b - a) / 2
    extra = ceil_fraction(STRENGTH * TIME_MAX * radius * SCALE)
    threshold = limit - extra
    # Duhamel also gives d(t,lambda) <= (7/20)*t*lambda directly from lambda=0.
    # Retain this bound on a dyadic prefix and refine the remaining time cells.
    start = Fraction(0)
    direct = 0
    for j in range(1, 65):
        x = Fraction(j, 64)
        upper = ceil_fraction(STRENGTH * TIME_MAX * b * x * SCALE)
        if upper > limit:
            break
        start, direct = x, upper
    if start == 1:
        return [direct, 0, 0]

    def point(x):
        return max(chords(model, x, p, "XYZ"))

    stack = [(start, Fraction(1), point(start), point(Fraction(1)), 0)]
    tested, leaves, max_chord = 2, 0, direct
    while stack:
        x, y, left, right, depth = stack.pop()
        # A 2-Lipschitz function is bounded by the minimum of the two cones.
        # The minimum is bounded by their average, even if the input bounds
        # are imprecise or the cones do not intersect inside the cell.
        time_extra = ceil_fraction(2 * TIME_MAX * (y - x) * SCALE)
        bound = (left + right + time_extra + 1) // 2
        if bound <= threshold:
            max_chord = max(max_chord, bound + extra)
            leaves += 1
        else:
            if max(left, right) > threshold or depth >= 22:
                raise RuntimeError(f"Global certificate failed at p={p}, lambda=[{a},{b}], time=[{x},{y}]")
            mid = (x + y) / 2
            value = point(mid)
            tested += 1
            stack.extend([(mid, y, value, right, depth + 1), (x, mid, left, value, depth + 1)])
    return [max_chord, tested, leaves]


def verify_global(p, n, witness):
    limit = chord_limit(n)
    cells = [global_cell(p, a, b, limit) for a, b in lambda_cells(witness)]
    bound = max(c[0] for c in cells)
    product = power_down(affinity_lower(bound), 2 * n)
    assert proves_impossibility(product)
    return {
        "impossible_through": str(witness["impossible_through"]),
        "scaled_max_chord": bound,
        "scaled_squared_affinity_lower": product,
        "lambda_cells": len(cells),
        "time_nodes_checked": sum(c[1] for c in cells),
        "time_leaves": sum(c[2] for c in cells),
    }


def verify_fixed(p, n, witness):
    schedule = SCHEDULES[p, n]
    min_product = AFFINITY_SCALE
    tested = 0
    for a, b in lambda_cells(witness):
        model = IntegerState((a + b) / 2)
        radius = (b - a) / 2
        product = AFFINITY_SCALE
        for basis, time_str, count in schedule:
            t = Fraction(time_str)
            chord, = chords(model, t / TIME_MAX, p, basis)
            chord += ceil_fraction(STRENGTH * t * radius * SCALE)
            product = product * power_down(affinity_lower(chord), 2 * count) // AFFINITY_SCALE
            tested += 1
        if not proves_impossibility(product):
            raise RuntimeError(f"Fixed certificate failed at p={p}, lambda=[{a},{b}]")
        min_product = min(min_product, product)
    return {
        "impossible_through": str(witness["impossible_through"]),
        "scaled_squared_affinity_lower": min_product,
        "point_settings_checked": tested,
        "schedule": schedule,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("previous", type=Path)
    parser.add_argument("output", type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--scaling", action="store_true", help="Also check the 1000/10000/100000-shot rows")
    mode.add_argument("--scaling-case", nargs=2, metavar=("P", "N"), help="Check one scaling row only")
    args = parser.parse_args()
    previous = json.loads(args.previous.read_text(encoding="utf-8"), parse_float=Fraction)
    result = {
        "chord_scale": SCALE,
        "affinity_scale": AFFINITY_SCALE,
        "failure_criterion": "squared product of affinities > 19/100",
        "global": {},
        "fixed": {},
    }

    def save():
        args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    def check(kind, p, n, witness):
        fun = verify_fixed if kind == "fixed" else verify_global
        row = fun(Fraction(p), n, witness)
        result[kind][f"p={p},n={n}"] = row
        print(kind, f"p={p} n={n}", row, flush=True)
        save()

    if args.scaling_case is not None:
        p, n = args.scaling_case
        if p not in ("0.0", "0.02", "0.05") or n not in ("1000", "10000", "100000"):
            parser.error("--scaling-case expects P=0.0/0.02/0.05 and N=1000/10000/100000")
        check("global", p, int(n), previous["weak_link"][p][n]["lower"])
        return

    for p, n in (("0.0", 62), ("0.02", 80), ("0.05", 106), ("0.05", 105)):
        if n == 105:
            source = previous["replay_weak_link"][p]
            fixed, lower = source["fixed"], source["global_lower"]
        else:
            fixed = previous["fixed_weak_link"][p]
            lower = previous["weak_link"][p][str(n)]["lower"]
        check("fixed", p, n, fixed)
        check("global", p, n, lower)
    if args.scaling:
        for p in ("0.0", "0.02", "0.05"):
            for n in (1000, 10000, 100000):
                check("global", p, n, previous["weak_link"][p][str(n)]["lower"])


if __name__ == "__main__":
    main()
