"""Independently verify the saved 64-graph and weak-link upper witnesses.

All certified bounds use integer or rational arithmetic. NumPy performs
only uint64 operations with explicit limb sizes in the score convolution.
The inputs are fixed designs, scores, and thresholds from the first audit.
"""
import argparse
from collections import defaultdict
import csv
from fractions import Fraction
from functools import lru_cache
from itertools import combinations
import json
from math import factorial, isqrt, lcm, prod
from pathlib import Path

import numpy as np


BONDS = tuple(combinations(range(4), 2))
OPEN_BONDS = {(0, 1): Fraction(1), (1, 2): Fraction(1), (2, 3): Fraction(1)}
OUTCOMES = range(16)
TAYLOR_ORDER = 100
PROB_SCALE = 10**40
MASS_BITS = 48
MASS_SCALE = 1 << MASS_BITS
LIMB_BITS = MASS_BITS // 2
LIMB_MASK = (1 << LIMB_BITS) - 1
TAIL = Fraction(16 ** (TAYLOR_ORDER + 1), factorial(TAYLOR_ORDER + 1)) / (
    1 - Fraction(16, TAYLOR_ORDER + 2)
)
PROB_ERROR = (2 + TAIL) * TAIL


def ceil_ratio(a, b):
    return -(-a // b)


def decimal_bound(a, b, places=12, upper=True):
    base = 10**places
    digits = ceil_ratio(a * base, b) if upper else a * base // b
    return f"{digits // base}.{digits % base:0{places}d}"


def state_horner(bonds, t):
    # Use H*t as a matrix with one common denominator. For the scalar
    # exponential Taylor polynomial, V_j = e_0 + (-iHt)/(j+1) V_{j+1}.
    diag = [
        t * Fraction(7, 20) * sum(
            strength if (x >> (3 - a) ^ x >> (3 - b)) & 1 == 0 else -strength
            for (a, b), strength in bonds.items()
        )
        for x in OUTCOMES
    ]
    off = t / 2
    assert max(map(abs, diag)) + 4 * abs(off) < 16
    denominator = lcm(off.denominator, *(x.denominator for x in diag))
    d = [int(x * denominator) for x in diag]
    c = int(off * denominator)

    def apply_matrix(v):
        return [
            d[x] * v[x] + c * (v[x ^ 1] + v[x ^ 2] + v[x ^ 4] + v[x ^ 8])
            for x in OUTCOMES
        ]

    real, imag = [1] + [0] * 15, [0] * 16
    scale = 1
    for j in range(TAYLOR_ORDER, 0, -1):
        real, imag = apply_matrix(imag), [-v for v in apply_matrix(real)]
        scale *= j * denominator
        real[0] += scale
    return real, imag, scale


def probability_enclosures(bonds, basis, time, p):
    real, imag, scale = state_horner(bonds, time)
    if basis == "Y":
        for i in OUTCOMES:
            for _ in range(i.bit_count()):
                real[i], imag[i] = imag[i], -real[i]
    if basis in ("X", "Y"):
        # Four Hadamard butterflies. Each contributes a global 1/sqrt(2),
        # giving one factor 1/4 for the full basis change.
        for bit in (1, 2, 4, 8):
            for x in OUTCOMES:
                if x & bit == 0:
                    y = x | bit
                    real[x], real[y] = real[x] + real[y], real[x] - real[y]
                    imag[x], imag[y] = imag[x] + imag[y], imag[x] - imag[y]
        scale *= 4
    else:
        assert basis == "Z"

    q = [r*r + s*s for r, s in zip(real, imag, strict=True)]
    keep, flip = p.denominator - p.numerator, p.numerator
    for bit in (1, 2, 4, 8):
        for x in OUTCOMES:
            if x & bit == 0:
                y = x | bit
                q[x], q[y] = keep * q[x] + flip * q[y], flip * q[x] + keep * q[y]
    scale = scale**2 * p.denominator**4
    # Each Taylor probability differs by at most (2+r)r after the unitary
    # rotation. The readout channel is row stochastic and preserves this
    # per-outcome bound. All rounding of the endpoints is outward.
    p_lower, p_upper = [], []
    for n in q:
        center = Fraction(n, scale)
        low = (center - PROB_ERROR) * PROB_SCALE
        high = (center + PROB_ERROR) * PROB_SCALE
        p_lower.append(max(0, low.numerator // low.denominator))
        p_upper.append(min(PROB_SCALE, ceil_ratio(high.numerator, high.denominator)))
    assert sum(p_lower) <= PROB_SCALE <= sum(p_upper)
    return tuple(p_lower), tuple(p_upper)


@lru_cache(maxsize=None)
def weak_probs(basis, t, p, strength):
    return probability_enclosures({**OPEN_BONDS, (0, 3): strength}, basis, t, p)


def lower_convolution(settings):
    # The total stored mass is at most 2^48. Multiplication uses 24-bit
    # limbs so that the cross sum is at most 2^49 and does not wrap.
    mass = np.array([MASS_SCALE], dtype=np.uint64)
    start_score = 0
    for shots, probs, scores in settings:
        grouped = defaultdict(int)
        for prob, score in zip(probs, scores, strict=True):
            grouped[score] += prob
        assert sum(grouped.values()) <= PROB_SCALE
        width = max(grouped) - min(grouped)
        coefficients = [
            (score - min(grouped), prob * MASS_SCALE // PROB_SCALE)
            for score, prob in sorted(grouped.items())
        ]
        for _ in range(shots):
            new = np.zeros(len(mass) + width, dtype=np.uint64)
            lo = mass & LIMB_MASK
            hi = mass >> LIMB_BITS
            for shift, coefficient in coefficients:
                qlo, qhi = coefficient & LIMB_MASK, coefficient >> LIMB_BITS
                cross = hi * qlo + lo * qhi + ((lo * qlo) >> LIMB_BITS)
                increment = hi * qhi + (cross >> LIMB_BITS)
                new[shift:shift + len(mass)] += increment
            # Each stored mass and their sum are bounded by MASS_SCALE by
            # induction. The products were floored and one-shot mass <= 1.
            assert int(new.sum(dtype=np.uint64)) <= MASS_SCALE
            mass = new
        start_score += shots * min(grouped)
    return mass, start_score


def check_score_certificates(path):
    result = []
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            design = json.loads(row["design"], parse_float=Fraction)
            p, strength = Fraction(row["p_flip"]), Fraction(row["lambda"])
            scores = json.loads(row["outcome_scores"])
            threshold = int(row["threshold"])
            errors = []
            for side, lam in enumerate((Fraction(0), strength)):
                settings = [
                    (shots, weak_probs(basis, t, p, lam)[0], setting_scores)
                    for (basis, t, shots), setting_scores in zip(design, scores, strict=True)
                ]
                mass, start_score = lower_convolution(settings)
                nle = min(len(mass), max(0, threshold - start_score + 1))
                le = int(mass[:nle].sum(dtype=np.uint64))
                gt = int(mass[nle:].sum(dtype=np.uint64))
                wrong, right = (gt, le) if side == 0 else (le, gt)
                upper = MASS_SCALE - right
                assert 20 * upper <= MASS_SCALE
                errors.append({
                    "lower_numerator": wrong,
                    "upper_numerator": upper,
                    "denominator": MASS_SCALE,
                    "lower_rounded_down": decimal_bound(wrong, MASS_SCALE, upper=False),
                    "upper_rounded_up": decimal_bound(upper, MASS_SCALE),
                })
            result.append({
                "family": row["family"], "p": row["p_flip"], "N": int(row["shots"]),
                "case": row["case"], "lambda": row["lambda"], "allocation": json.loads(row["design"]),
                "threshold": threshold, "outcome_scores": scores,
                "null_error": errors[0], "alt_error": errors[1],
            })
            print("weak score", row["p_flip"], row["shots"], row["case"],
                  *(x["upper_rounded_up"] for x in errors), flush=True)
    assert len(result) == 8
    return result


@lru_cache(maxsize=None)
def graph_uppers(basis, t, p):
    uppers = [
        probability_enclosures(
            {bond: Fraction(1) for i, bond in enumerate(BONDS) if g & (1 << i)},
            basis, t, p
        )[1]
        for g in range(64)
    ]
    affinities = []
    for i, j in combinations(range(64), 2):
        terms = []
        for a, b in zip(uppers[i], uppers[j], strict=True):
            n = a * b
            root = isqrt(n)
            terms.append(root + int(root**2 < n))
        affinities.append(min(PROB_SCALE, sum(terms)))
    return affinities


def check_union_certificates(path):
    designs = json.loads(path.read_text(encoding="utf-8"))
    result = {}
    for name, value in designs.items():
        if not name.endswith("union"):
            continue
        p = Fraction(str(value["p"]))
        terms = [
            (graph_uppers(basis, Fraction(str(time)), p), n)
            for basis, time, n in value["allocation"]
        ]
        shots = sum(n for _, n in terms)
        errors = [0] * 64
        for k, (g, h) in enumerate(combinations(range(64), 2)):
            upper = prod(affinities[k] ** n for affinities, n in terms)
            errors[g] += upper
            errors[h] += upper
        worst = max(errors)
        assert 20 * worst <= PROB_SCALE**shots
        upper_text = decimal_bound(worst, PROB_SCALE**shots)
        result[name] = {
            "shots": shots, "worst_graph_id": errors.index(worst),
            "error_upper_rounded_up": upper_text, "allocation": value["allocation"],
        }
        print("union", name, shots, upper_text, flush=True)
    assert len(result) == 3
    return result


def upper_exp(x):
    term, partial = Fraction(1), Fraction(1)
    for j in range(1, 49):
        term *= x / j
        partial += term
    assert abs(x) < 50
    tail = abs(term * x / 49) / (1 - abs(x) / 50)
    return partial + tail


def upward_pow(numerator, exponent):
    # Return an upper enclosure on (numerator/PROB_SCALE)**exponent.
    acc = PROB_SCALE
    while exponent:
        if exponent & 1:
            acc = ceil_ratio(acc * numerator, PROB_SCALE)
        exponent >>= 1
        numerator = ceil_ratio(numerator * numerator, PROB_SCALE)
    return acc


def check_chernoff_upper(p, strength, settings, scores, threshold, tilt):
    errors = []
    for sign, lam in ((1, Fraction(0)), (-1, strength)):
        exponent = -sign * tilt * threshold
        factor = upper_exp(exponent) * PROB_SCALE
        upper = ceil_ratio(factor.numerator, factor.denominator)
        for (basis, time, shots), row in zip(settings, scores, strict=True):
            q = weak_probs(basis, Fraction(time), p, lam)[1]
            # q was already rounded up at PROB_SCALE. MGF sum uses exact
            # rational exp upper terms, then rounds the complete sum up.
            moment = sum(n * upper_exp(sign * tilt * s) for n, s in zip(q, row, strict=True))
            m = ceil_ratio(moment.numerator, moment.denominator)
            upper = ceil_ratio(upper * upward_pow(m, shots), PROB_SCALE)
        assert 20 * upper <= PROB_SCALE
        errors.append(decimal_bound(upper, PROB_SCALE))
    return errors


def check_chernoff_certificates(path):
    old = json.loads(path.read_text(encoding="utf-8"), parse_float=Fraction)
    result = []
    for p, rows in old["weak_link"].items():
        for shots, values in rows.items():
            up = values["upper"]
            settings = [(up["basis"], up["time"], int(shots))]
            errors = check_chernoff_upper(
                Fraction(p), up["achievable_at"], settings, [up["scores"]], up["threshold"], up["tilt"]
            )
            result.append({"p": p, "N": int(shots), "case": "dedicated",
                           "lambda": str(up["achievable_at"]), "errors_rounded_up": errors})
            print("weak Chernoff", p, shots, "dedicated", *errors, flush=True)

    fixed_rows = list(old["fixed_weak_link"].items())
    fixed_rows.extend((p, x["fixed"]) for p, x in old["replay_weak_link"].items())
    for p, value in fixed_rows:
        up = value["upper"]
        errors = check_chernoff_upper(
            Fraction(p), up["achievable_at"], value["schedule"], up["scores"], up["threshold"], up["tilt"]
        )
        shots = sum(n for _, _, n in value["schedule"])
        result.append({"p": p, "N": shots, "case": "fixed",
                       "lambda": str(up["achievable_at"]), "errors_rounded_up": errors})
        print("weak Chernoff", p, shots, "fixed", *errors, flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--score", type=Path, required=True)
    parser.add_argument("--union", type=Path, required=True)
    parser.add_argument("--chernoff", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = {
        "weak_score": check_score_certificates(args.score),
        "union": check_union_certificates(args.union),
    }
    if args.chernoff:
        data["weak_chernoff"] = check_chernoff_certificates(args.chernoff)
    args.output.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
