"""Holdout Monte Carlo audit for fixed designs in finite_shot_topology.py."""

import argparse
import csv
from fractions import Fraction
from itertools import chain
import json
from pathlib import Path

import numpy as np
from scipy.stats import beta

import finite_shot_topology as model


# Original setting times and integer allocations in finite_shot_results.txt.
PUBLISHED = {
    0.0: (
        [("X", 2.272, 28), ("Z", 2.028, 7), ("Z", 2.376, 4), ("Z", 3.176, 10), ("Z", 3.688, 13)],
        [("Z", 2.304, 70)],
    ),
    0.02: ([("Z", 2.112, 70), ("Z", 3.280, 10)], [("Z", 2.300, 84)]),
    0.05: ([("X", 2.260, 5), ("Z", 2.104, 90), ("Z", 3.036, 11)], [("Z", 2.272, 109)]),
}
FAMILY_ALPHA = 0.05
TIE_ATOL = 1e-9
BATCH_SIZE = 8192


def replay_designs(path):
    rows = json.loads(path.read_text(encoding="utf-8"))
    designs = {}
    for p in model.P_FLIPS:
        row = rows[f"p={p}"]
        basis, time = row["single_setting"]
        designs[p] = (row["design"], [(basis, time, row["N_single_setting"])])
    return designs


def count_success(probabilities, weights, allocation, graph_id, trials, rng):
    successes = 0
    exact_float_successes = 0
    unresolved_margins = 0
    for start in range(0, trials, BATCH_SIZE):
        batch = min(BATCH_SIZE, trials - start)
        scores = np.zeros((batch, len(model.GRAPHS)))
        for k, shots in enumerate(allocation):
            if shots:
                counts = rng.multinomial(shots, probabilities[graph_id, k], size=batch)
                scores += counts @ weights[k]
        own = scores[:, graph_id].copy()
        scores[:, graph_id] = -np.inf
        margin = own - scores.max(axis=1)
        successes += np.count_nonzero(margin > TIE_ATOL)
        exact_float_successes += np.count_nonzero(margin > 0.0)
        unresolved_margins += np.count_nonzero(np.abs(margin) <= TIE_ATOL)
    return successes, exact_float_successes, unresolved_margins


def taylor_probs(settings, p):
    from verify_union_bound import probabilities

    flip = Fraction(str(p))
    out = np.empty((len(model.GRAPHS), len(settings), 16))
    for g in range(len(model.GRAPHS)):
        for k, (basis, time) in enumerate(settings):
            nums, denom = probabilities(g, basis, round(time, 3), flip)
            out[g, k] = [num / denom for num in nums]
    return out


def audit(designs, family, trials, seed, exact_taylor=False):
    actual_size = sum(len(group) for group in designs.values()) * len(model.GRAPHS)
    per_test_alpha = FAMILY_ALPHA / actual_size
    family_id = {"published": 0, "replay": 1, "published_multiple": 2, "replay_multiple": 3}[family]
    streams = iter(np.random.SeedSequence(seed, spawn_key=(family_id,)).spawn(actual_size))
    labels = ("multiple_settings",) if family.endswith("_multiple") else ("multiple_settings", "single_setting")
    for p, group in designs.items():
        for label, design in zip(labels, group, strict=True):
            settings = [(basis, time) for basis, time, _ in design]
            allocation = [shots for _, _, shots in design]
            oracle = taylor_probs if exact_taylor else model.setting_probs
            probabilities = oracle(settings, p)
            probabilities /= probabilities.sum(axis=2, keepdims=True)
            weights = np.ascontiguousarray(model.log_weights(probabilities, "ml").transpose(1, 2, 0))
            for graph_id, edges in enumerate(model.GRAPHS):
                child = next(streams)
                rng = np.random.default_rng(child)
                successes, float_successes, ties = count_success(
                    probabilities, weights, allocation, graph_id, trials, rng
                )
                lower = float(beta.ppf(per_test_alpha, successes, trials - successes + 1)) if successes else 0.0
                yield {
                    "family": family,
                    "p_flip": p,
                    "design": label,
                    "total_shots": sum(allocation),
                    "settings_basis_time_shots": json.dumps(design, separators=(",", ":")),
                    "graph_id": graph_id,
                    "graph_edges": model.gname(edges),
                    "successes": successes,
                    "trials": trials,
                    "estimated_success": successes / trials,
                    "cp_simultaneous_lower_95": lower,
                    "lower_at_least_0_95": lower >= 0.95,
                    "successes_float_strict_gt_zero": float_successes,
                    "own_rival_score_margin_within_tolerance": ties,
                    "tie_margin_tolerance": TIE_ATOL,
                    "family_size": actual_size,
                    "per_test_alpha": per_test_alpha,
                    "root_seed": seed,
                    "seed_spawn_key": json.dumps(child.spawn_key, separators=(",", ":")),
                    "bit_generator": type(rng.bit_generator).__name__,
                    "probability_oracle": "rational_taylor_float" if exact_taylor else "eigendecomposition_float",
                }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--replay", type=Path, help="Validate designs from a replay results JSON")
    parser.add_argument("--multiple-only", action="store_true", help="Validate only multi-setting designs")
    parser.add_argument("--p-flip", type=float, choices=model.P_FLIPS, help="Restrict to one readout flip rate")
    parser.add_argument("--trials", type=int, default=100_000)
    parser.add_argument("--seed", type=int, default=2026111302)
    parser.add_argument("--exact-taylor", action="store_true", help="Use rational Taylor probabilities converted to float")
    args = parser.parse_args()
    if args.trials < 1 or args.seed < 0:
        parser.error("trials must be positive and seed must be nonnegative")
    family, designs = "published", PUBLISHED
    if args.replay is not None:
        family, designs = "replay", replay_designs(args.replay)
    if args.multiple_only:
        family += "_multiple"
        designs = {p: (multiple,) for p, (multiple, _) in designs.items()}
    if args.p_flip is not None:
        designs = {args.p_flip: designs[args.p_flip]}
    rows = audit(designs, family, args.trials, args.seed, exact_taylor=args.exact_taylor)
    first = next(rows)
    summary = {}
    with args.output.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=first.keys())
        writer.writeheader()
        for row in chain((first,), rows):
            writer.writerow(row)
            key = (row["p_flip"], row["design"])
            summary.setdefault(key, []).append(row)
            if len(summary[key]) == len(model.GRAPHS):
                stream.flush()
                worst = min(summary[key], key=lambda record: record["cp_simultaneous_lower_95"])
                print(
                    f"{family} p={key[0]:.0%} {key[1]} N={worst['total_shots']} "
                    f"worst_graph={worst['graph_id']} successes={worst['successes']}/{args.trials} "
                    f"lower={worst['cp_simultaneous_lower_95']:.8f} "
                    f"ties={sum(r['own_rival_score_margin_within_tolerance'] for r in summary[key])} "
                    f"strict_float_diff={sum(r['successes_float_strict_gt_zero']-r['successes'] for r in summary[key])}",
                    flush=True,
                )


if __name__ == "__main__":
    main()
