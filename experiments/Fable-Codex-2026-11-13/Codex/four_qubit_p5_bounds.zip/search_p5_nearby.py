"""Local joint search over integer score tables and class biases (heuristic FFT)."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp, softmax

import finite_shot_topology as model
from search_p5_integer_design import graph_symmetry, tails_for_all_pairs


SETTINGS = [("Z", 2.104), ("Z", 3.036)]


class BiasSearch:
    def __init__(self, tails, k, support, tie_weight):
        self.k = k
        self.g = np.array([t.true_class for t in tails])
        self.h = np.array([t.rival_class for t in tails])
        self.m = np.array([t.multiplicity for t in tails])
        self.support = support
        grid = np.arange(-support, support + 2)
        rows = []
        for t in tails:
            def at(grid):
                i = grid - t.minimum
                return np.where(i < 0, 1, np.where(i < len(t.tail), t.tail[np.clip(i, 0, len(t.tail)-1)], 0))
            rows.append(tie_weight * at(grid) + (1 - tie_weight) * at(grid+1))
        self.t = np.array(rows)
        self.row = np.arange(len(tails))

    def score(self, b):
        d = b[self.g] - b[self.h] + self.support
        j = d.astype(int)
        a = self.t[self.row, j]
        return np.bincount(self.g, weights=self.m * a, minlength=self.k)

    def smooth(self, b, alpha):
        b = np.r_[0., b]
        d = b[self.g] - b[self.h] + self.support
        j = d.astype(int)
        x = d - j
        a = self.t[self.row, j]
        dy = self.t[self.row, j+1] - a
        loss = np.bincount(self.g, weights=self.m*(a + x * dy), minlength=self.k)
        w = self.m * softmax(alpha*loss)[self.g] * dy
        grad = np.bincount(self.g, weights=w, minlength=self.k) - np.bincount(self.h, weights=w, minlength=self.k)
        return logsumexp(alpha*loss)/alpha, grad[1:]

    def optimize(self, b, scale, seed, refine):
        out = None
        rng = np.random.default_rng(seed)
        limit = (5 if refine else 2) * scale
        temperatures = (250., 900., 3200., 12800.)
        if refine:
            temperatures += (51200., 204800.)
        for r in range(2):
            x = np.asarray(b, float)
            if r:
                x = x + rng.uniform(-3, 3, self.k)
            x = np.clip(x[1:], -limit, limit)
            for alpha in temperatures:
                opt = minimize(self.smooth, x, args=(alpha,), jac=True, method="L-BFGS-B",
                               bounds=[(-limit, limit)]*len(x),
                               options={"maxiter":100,"ftol":1e-12,"gtol":1e-10})
                x = opt.x
            center = np.r_[0., x]
            for a in [np.rint(center), np.floor(center), np.ceil(center)] + [
                np.floor(center+rng.uniform(size=len(center))) for _ in range(12)
            ]:
                a = a.astype(int)
                val = self.score(a).max()
                if out is None or val < out[0]:
                    out = val, a
        val, best = out
        for _ in range(12):
            old = val
            for i in rng.permutation(np.arange(1, self.k)):
                start = best[i]
                vals = []
                for change in (-2,-1,1,2):
                    b = best.copy()
                    b[i] = start + change
                    y = self.score(b).max()
                    vals.append((y, b))
                v, b = min(vals, key=lambda row: row[0])
                if v < val:
                    val, best = v, b
            if val >= old:
                break
        return best


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("allocation", "scores", "refine"), required=True)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--start", type=Path)
    args = parser.parse_args()
    p = model.setting_probs(SETTINGS, 0.05)
    p /= p.sum(axis=2, keepdims=True)
    l = np.log(p)
    reps, classes, pairs = graph_symmetry()
    initial = json.loads(Path("p5_integer_candidate_103.json").read_text(encoding="utf-8"))
    initial_bias = np.array(initial["integer_bias"])[reps]
    if args.stage == "allocation":
        cases = [(N,k,32,1.,0.) for N in (102,101) for k in (13,12,14,11,15,10,16,9,17,8,18)]
    else:
        previous = json.loads(args.start.read_text(encoding="utf-8"))
        unique = [(row["N"],row["design"][1][2]) for row in previous]
        knobs = [
            (32,0.97,0),(32,1.03,0),(32,0.92,0),(32,1.08,0),
            (64,1.,0),(64,0.98,0),(64,1.02,0),
            (16,1.,0),(16,0.95,0),(16,1.05,0),
            (24,1.,0),(48,1.,0),(96,1.,0),(128,1.,0),
            (32,1.,.25),(32,1.,-.25),(24,1.,.35),(64,1.,.35),
        ] if args.stage == "scores" else [
            (32,1.,0),(64,1.,0),(128,1.,0),(256,1.,0),
            (128,.98,0),(128,1.02,0),(128,1.,-.35),(128,1.,.35),
        ]
        cases = [(N,k,s,r,d) for N,k in unique for s,r,d in knobs]
    history = []
    best = {}
    for i,(N,k,scale,ratio,shift) in enumerate(cases):
        scores = np.rint(l * np.array([scale,scale*ratio])[None,:,None] + shift).astype(int)
        n = (N-k, k)
        tails = tails_for_all_pairs(scores, p, n, classes, pairs)
        for tie in (0.5, 1.0):
            refine = args.stage == "refine"
            support = 10*scale+64 if refine else 5*scale+24
            obj = BiasSearch(tails,len(reps), support, tie)
            w = obj.optimize(initial_bias*scale/32., scale, 47+i, refine)
            sums = obj.score(w)
            upper = float(sums.max())
            print(N,n,scale,ratio,shift,tie,upper,w.tolist(),flush=True)
            row = dict(N=N,design=[list(x)+[m] for x,m in zip(SETTINGS,n,strict=True)],
                       representative_graphs=reps.tolist(), approximate_pair_sums=sums.tolist(),
                       approx_max_error_upper=upper,log_rounding_scale=scale,
                       relative_second_scale=ratio, rounding_shift=shift, tie_weight=tie)
            history.append(row)
            key = (N,tie)
            if key not in best or upper < best[key]:
                best[key] = upper
                row = dict(row,integer_scores=scores.tolist(),integer_bias=w[classes].tolist())
                Path(f"{args.prefix}_{N}_{int(10*tie)}.json").write_text(json.dumps(row,indent=2)+"\n",encoding="utf-8")
        Path(f"{args.prefix}_history.json").write_text(json.dumps(history,indent=2)+"\n",encoding="utf-8")


if __name__ == "__main__":
    main()
