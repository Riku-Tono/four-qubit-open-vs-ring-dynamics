"""Sharpen a strict-score certificate with rigorous pair-event intersections.

For each true graph, put an edge between selected rival events. On an
outcome with k>0 failing comparisons, a forest has at most k-1 edges
among those k vertices. Therefore the sum of individual event bounds
minus a lower bound on each forest intersection bounds the union.

The fixed-forest replay uses integer arithmetic throughout. The optional
sampling path chooses edges and has no role in certifying their bounds.
"""
import argparse
from collections import defaultdict
from itertools import combinations, permutations
from math import isqrt
import json
from pathlib import Path

import numpy as np

from certify_p5_integer_design import PAIRS, SCALE, certify, graph_symmetry, probability_lower


COEFF_BITS = 32
COEFF_SCALE = 1 << COEFF_BITS
COEFF_MASK = COEFF_SCALE - 1


def ceildiv(a, b):
    return -(-a // b)


def coarsen(differences, shot_probabilities, shots, threshold, block):
    """A coarsened score crossing is sufficient for an original crossing."""
    rounded = []
    for ds, ps, n in zip(differences, shot_probabilities, shots, strict=True):
        shift = min(range(block), key=lambda s: sum(((int(d)-s) % block)*p for d,p in zip(ds,ps,strict=True)))
        rounded.append((ds-shift)//block)
        threshold -= n*shift
    return np.array(rounded), ceildiv(threshold, block)


def rectangles(mass, origin, grouped, mean_target, variance_target):
    """Propagate subprobability mass and discard cells outside a window."""
    x0, y0 = origin
    x1, y1 = x0+mass.shape[0], y0+mass.shape[1]
    xlow, ylow = (min(d[i] for d in grouped) for i in (0,1))
    xhigh, yhigh = (max(d[i] for d in grouped) for i in (0,1))
    centers = [m//COEFF_SCALE for m in mean_target]
    radii = [isqrt(36*v//COEFF_SCALE)+10 for v in variance_target]
    a0 = max(x0+xlow, centers[0]-radii[0])
    a1 = min(x1+xhigh, centers[0]+radii[0]+1)
    b0 = max(y0+ylow, centers[1]-radii[1])
    b1 = min(y1+yhigh, centers[1]+radii[1]+1)
    new = np.zeros((max(0,a1-a0),max(0,b1-b0)),dtype=np.uint64)
    hi = mass >> COEFF_BITS
    lo = mass & COEFF_MASK
    for (dx,dy), q in grouped.items():
        xlo,xhi = max(a0,x0+dx),min(a1,x1+dx)
        ylo,yhi = max(b0,y0+dy),min(b1,y1+dy)
        if xlo<xhi and ylo<yhi:
            src = np.s_[xlo-x0-dx:xhi-x0-dx,ylo-y0-dy:yhi-y0-dy]
            dst = np.s_[xlo-a0:xhi-a0,ylo-b0:yhi-b0]
            # floor(mass*q/2**32), with both products below 2**64.
            new[dst] += hi[src]*q + ((lo[src]*q) >> COEFF_BITS)
    return new,(a0,b0)


def lower_intersection(inc1, inc2, t1, t2, probabilities, shots):
    mass = np.array([[SCALE]],dtype=np.uint64)
    origin = (0,0)
    means, variances = [0,0],[0,0]
    settings = list(zip(inc1, inc2, probabilities, shots, strict=True))
    settings.sort(key=lambda row: row[3])
    for d1,d2,ps,n in settings:
        grouped = defaultdict(int)
        for x,y,p in zip(d1,d2,ps,strict=True):
            grouped[int(x),int(y)] += p
        grouped = {d:q for d,m in grouped.items() if (q := m >> (48-COEFF_BITS))}
        assert all(q < COEFF_SCALE for q in grouped.values()) and sum(grouped.values()) <= COEFF_SCALE
        scaled_means = [sum(d[i]*q for d,q in grouped.items()) for i in (0,1)]
        scaled_vars = [max(COEFF_SCALE, sum(d[i]**2*q for d,q in grouped.items()) -
                           (scaled_means[i]**2//COEFF_SCALE)) for i in (0,1)]
        for _ in range(n):
            for i in (0,1):
                means[i] += scaled_means[i]
                variances[i] += scaled_vars[i]
            mass,origin = rectangles(mass,origin,grouped,means,variances)
            if not mass.size:
                return 0
    assert int(mass.sum(dtype=np.uint64)) <= SCALE
    return int(mass[max(0,t1-origin[0]):,max(0,t2-origin[1]):].sum(dtype=np.uint64))


def rank_edges(g,rounded,thresholds,p,shots,trials,rng):
    # The sampled edges only suggest a forest. Their intersections are
    # re-evaluated by lower_intersection without sampling for the certificate.
    hits = np.zeros((trials,64),dtype=bool)
    step = 25000
    for j in range(0,trials,step):
        stop = min(j+step,trials)
        totals = np.zeros((stop-j,64))
        for k,n in enumerate(shots):
            if n:
                counts = rng.multinomial(n,p[g,k],size=stop-j).astype(float)
                totals += counts @ rounded[:,k,:].T.astype(float)
        hits[j:stop] = totals >= thresholds
    n_hit = hits.sum(axis=0)
    n_hit[g]=0
    useful = np.where(n_hit>0)[0]
    small = hits[:,useful].astype(float)
    both = small.T @ small
    return sorted(((int(both[i,j]),int(useful[i]),int(useful[j]))
                   for i,j in combinations(range(len(useful)),2) if both[i,j]),
                  reverse=True)


def stabilizers(reps):
    graph_maps = []
    for permutation in permutations(range(4)):
        mapped = [1 << PAIRS.index(tuple(sorted((permutation[a],permutation[b])))) for a,b in PAIRS]
        graph_maps.append([sum(mapped[i] for i in range(6) if graph & (1 << i)) for graph in range(64)])
    return {int(g):[mapping for mapping in graph_maps if mapping[g] == g] for g in reps}


def certify_overlaps(candidate, union, block, trials, verify_forest=None, graphs=None):
    design = candidate["design"]
    scores = np.array(candidate["integer_scores"],dtype=np.int64)
    bias = np.array(candidate["integer_bias"],dtype=np.int64)
    shots = [n for _,_,n in design]
    reps,classes,_ = graph_symmetry(scores,bias)
    if verify_forest is None:
        import finite_shot_topology as model

        p = model.setting_probs([(b,t) for b,t,_ in design], .05)
        p /= p.sum(axis=2,keepdims=True)
    sym = stabilizers(reps)
    assert graphs is None or set(graphs) <= set(reps)
    before = union["representative_upper_numerators"]
    after = {}
    forest = {}
    rng=np.random.default_rng(2026111321)
    for g in map(int,reps):
        if graphs is not None and g not in graphs:
            continue
        upper = before[g] if g in before else before[str(g)]
        after[g] = upper
        forest[g] = []
        if 20*upper <= SCALE:
            continue
        probs = [probability_lower(g,b,t) for b,t,_ in design]
        roundings = [coarsen(scores[h]-scores[g],probs,shots,int(bias[g]-bias[h]),block)
                     for h in range(64)]
        rounded = np.array([x for x,_ in roundings])
        thresholds = np.array([t for _,t in roundings])
        edges = (rank_edges(g,rounded,thresholds,p,shots,trials,rng)[:20] if verify_forest is None else
                 [(None,x["rival1"],x["rival2"]) for x in verify_forest[str(g)]])
        component=list(range(64))
        intersection_cache = {}
        for estimated,h,j in edges:
            assert 0 <= h < 64 and 0 <= j < 64 and h != g and j != g and h != j
            if component[h]==component[j]:
                assert verify_forest is None, "saved forest contains a cycle"
                continue
            key = min(tuple(sorted((mapping[h],mapping[j]))) for mapping in sym[g])
            if key not in intersection_cache:
                k1,k2 = key
                intersection_cache[key] = lower_intersection(rounded[k1],rounded[k2],thresholds[k1],thresholds[k2],probs,shots)
            lower = intersection_cache[key]
            if not lower:
                continue
            a,b=component[h],component[j]
            component=[a if x==b else x for x in component]
            forest[g].append(dict(rival1=h,rival2=j,intersection_lower_numerator=lower))
            upper -= lower
            after[g]=upper
            print(g,h,j,estimated,lower/SCALE,upper/SCALE,flush=True)
            if 20*upper <= SCALE:
                break
    return dict(denominator=SCALE, block=block, representative_upper_numerators=after,
                forest=forest, graph_upper_numerators=[after.get(int(reps[classes[g]])) for g in range(64)],
                worst_numerator=max(after.values()),
                certifies_all_64_at_95=len(after)==len(reps) and 20*max(after.values())<=SCALE)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate",type=Path,required=True)
    parser.add_argument("--union",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--block",type=int,default=4)
    parser.add_argument("--trials",type=int,default=180000)
    parser.add_argument("--verify-forest",type=Path,help="Recompute the selected intersections from an existing certificate")
    parser.add_argument("--graphs",nargs="+",type=int,help="Only compute selected representative graphs")
    args=parser.parse_args()
    candidate=json.loads(args.candidate.read_text(encoding="utf-8"))
    if args.union.exists():
        union=json.loads(args.union.read_text(encoding="utf-8"))
        assert candidate["design"] == union["design"]
        assert candidate["integer_scores"] == union["integer_scores"]
        assert candidate["integer_bias"] == union["integer_bias"]
        assert union["denominator"] == SCALE
    else:
        union=certify(candidate)
        args.union.write_text(json.dumps(union,indent=2),encoding="utf-8")
    forest = None if args.verify_forest is None else json.loads(args.verify_forest.read_text(encoding="utf-8"))["forest"]
    out=certify_overlaps(candidate,union,args.block,args.trials,forest,args.graphs)
    args.output.write_text(json.dumps(out,indent=2),encoding="utf-8")
    print("worst",out["worst_numerator"]/SCALE,flush=True)


if __name__ == "__main__":
    main()
