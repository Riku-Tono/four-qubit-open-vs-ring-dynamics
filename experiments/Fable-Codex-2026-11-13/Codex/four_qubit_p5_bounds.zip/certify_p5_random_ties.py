"""Exact pairwise sum bound for a fixed integer score, with uniform random ties."""
import argparse
from fractions import Fraction
import json
from pathlib import Path

import numpy as np

from certify_p5_integer_design import P_FLIP, SCALE, graph_symmetry, pair_failure_upper, probability_lower


def certify_half_ties(candidate):
    design = candidate["design"]
    scores = np.asarray(candidate["integer_scores"], dtype=np.int64)
    bias = np.asarray(candidate["integer_bias"], dtype=np.int64)
    shots = [n for _, _, n in design]
    assert scores.shape == (64, len(design), 16) and bias.shape == (64,)
    assert sum(shots) == candidate["N"] and all(type(n) is int and n >= 0 for n in shots)
    assert int(np.abs(scores).max()) < (1 << 15) and int(np.abs(bias).max()) < (1 << 15)
    assert all(b in ("X", "Y", "Z") and 0 <= Fraction(str(t)) <= Fraction("3.688") for b,t,_ in design)
    reps, classes, pairs = graph_symmetry(scores, bias)
    p = {g: [probability_lower(int(g), b, t) for b,t,_ in design] for g in reps}
    totals = {int(g): 0 for g in reps}
    multiplicity = {int(g): 0 for g in reps}
    rows = []
    for g,h,m in pairs:
        threshold = int(bias[g]) - int(bias[h])
        delta = scores[h] - scores[g]
        # Independent uniform ordering makes h beat g with probability one half
        # when their scores tie. This event is covered by the two tails below.
        ge = pair_failure_upper(delta, p[g], shots, threshold)
        gt = pair_failure_upper(delta, p[g], shots, threshold+1)
        totals[g] += m * (ge + gt)
        multiplicity[g] += m
        rows.append({"true_graph":g,"rival_graph":h,"multiplicity":m,
                     "greater_equal_upper_numerator":ge,"greater_upper_numerator":gt})
    assert all(n == 63 for n in multiplicity.values())
    d = 2*SCALE
    upper = max(totals.values())
    result = dict(N=candidate["N"],p_flip=str(P_FLIP),design=design,
                  integer_scores=scores.tolist(),integer_bias=bias.tolist(),
                  denominator=d,representative_upper_numerators=totals,
                  graph_upper_numerators=[totals[int(reps[classes[g]])] for g in range(64)],
                  directed_pair_upper_bounds=rows,worst_numerator=upper,
                  tie_rule="select uniformly among the maximum-score graphs using independent randomness",
                  certifies_all_64_at_95=(20*upper<=d))
    print(f"{upper}/{d} = {upper/d:.12f}; pass={result['certifies_all_64_at_95']}",flush=True)
    return result


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    row=json.loads(args.candidate.read_text(encoding="utf-8"))
    result=certify_half_ties(row)
    args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
