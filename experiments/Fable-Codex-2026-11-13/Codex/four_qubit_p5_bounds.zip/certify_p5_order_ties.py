"""Make the certified half-tie rule deterministic using shot order."""
import argparse
from fractions import Fraction
import json
from pathlib import Path

import numpy as np

from certify_p5_integer_design import P_FLIP, PROBABILITY_ERROR, graph_symmetry
from verify_union_bound import probabilities


def ordered_tie_decision(scores, sequence):
    """Choose a maximum-score ID; sequence is the ordered first-setting outcomes."""
    best = max(scores)
    candidates = [g for g, score in enumerate(scores) if score == best]
    return candidates[0] if tuple(sequence) <= tuple(reversed(sequence)) else candidates[-1]


def ordered_certificate(half):
    assert Fraction(half["p_flip"]) == P_FLIP
    scores = np.asarray(half["integer_scores"], dtype=np.int64)
    bias = np.asarray(half["integer_bias"], dtype=np.int64)
    reps, _, _ = graph_symmetry(scores, bias)
    basis, time, shots = half["design"][0]
    collision_upper = Fraction(1,4)
    for g in reps:
        nums, den = probabilities(int(g), basis, time, P_FLIP)
        point_upper = [Fraction(a,den)+PROBABILITY_ERROR for a in nums]
        assert sum(x*x for x in point_upper) <= collision_upper

    # Reversing the first setting exchanges strict lexicographic orientations
    # while preserving the joint sampling law and every score. Therefore choosing
    # max-ID vs min-ID by orientation, plus a fair coin on palindromes, gives
    # probability one half for each tied pair to beat the other. Deterministic
    # min-ID on palindromes changes total error by at most half their probability.
    palindrome_upper = collision_upper ** (shots//2)
    correction = palindrome_upper / 2
    original_upper = Fraction(half["worst_numerator"], half["denominator"])
    total = original_upper + correction
    half.update({
        "tie_rule":"on top-score ties select min graph ID if first-setting outcomes are lexicographically <= their reverse, otherwise max graph ID",
        "reversal_setting":0,
        "collision_probability_upper":str(collision_upper),
        "palindrome_probability_upper":str(palindrome_upper),
        "palindrome_error_correction_upper":str(correction),
        "ordered_ties_worst_numerator":total.numerator,
        "ordered_ties_denominator":total.denominator,
        "certifies_all_64_at_95":total <= Fraction(1,20),
    })
    print(f"{total} = {float(total):.12f}; pass={half['certifies_all_64_at_95']}",flush=True)
    return half


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--half-certificate",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    half=json.loads(args.half_certificate.read_text(encoding="utf-8"))
    result=ordered_certificate(half)
    args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
