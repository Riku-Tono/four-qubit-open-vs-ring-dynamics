"""Screen nearby Z measurement schedules with epigraph bias optimization."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize

import finite_shot_topology as model
from search_p5_integer_design import graph_symmetry, tails_for_all_pairs, MinimizeWorstPairSum


class BiasScreen:
    def __init__(self, scale):
        self.reps, self.classes, self.pairs = graph_symmetry()
        self.scale = scale
        self.previous = np.array(json.loads(Path("p5_integer_candidate_103.json").read_text(encoding="utf-8"))["integer_bias"])[self.reps]
        self.previous = self.previous * (scale / 32)
        self.previous -= self.previous[0]

    def test(self, times, counts, incumbent=None, credit=None):
        settings = [("Z", time) for time in times]
        p = model.setting_probs(settings, .05)
        p /= p.sum(axis=2, keepdims=True)
        scores = np.rint(self.scale * np.log(p)).astype(int)
        rec = tails_for_all_pairs(scores, p, counts, self.classes, self.pairs)
        obj = MinimizeWorstPairSum(rec, len(self.reps), self.scale*4)
        rows, true, rival, multiplicity = obj.rows, obj.true, obj.rival, obj.multiplicities
        zero = 2 * obj.bound
        dim = len(self.reps)
        if credit is None:
            credit = np.zeros(dim)
        m = len(rows)
        slots = np.arange(m)
        prefactor = np.zeros((m, dim))
        prefactor[slots, true] = 1
        prefactor[slots, rival] -= 1

        def f(x, jac=False):
            w = np.r_[0, x[1:]]
            offset = (w[true] - w[rival] + zero).clip(0, 2*zero-1e-8)
            lo = np.floor(offset).astype(int)
            step = obj.tail[rows, lo+1] - obj.tail[rows, lo]
            if not jac:
                ev = multiplicity * (obj.tail[rows, lo] + step * (offset-lo))
                return x[0] - np.bincount(true, weights=ev, minlength=dim) + credit
            partial = -(multiplicity*step)[:,None] * prefactor[:,1:]
            j = np.zeros((dim, dim))
            j[:, 0] = 1.
            np.add.at(j[:, 1:], true, partial)
            return j

        w0 = self.previous if incumbent is None else incumbent
        x0 = np.r_[0.07, w0[1:]]
        sol = minimize(lambda x: x[0], x0, jac=lambda x: np.r_[1., np.zeros(dim-1)],
                       method="SLSQP", constraints=[dict(type="ineq", fun=f, jac=lambda x: f(x,True))],
                       bounds=[(0.,.2)] + [(-obj.bound,obj.bound)]*(dim-1),
                       options={"maxiter": 150, "ftol": 1e-10})
        w = np.rint(np.r_[0., sol.x[1:]]).astype(int)
        v = obj.values(w)
        for _ in range(12):
            prev = (v-credit).max()
            for j in range(1,dim):
                best_j = w[j]
                for off in (-2,-1,1,2):
                    trial = w.copy()
                    trial[j] += off
                    vt = obj.values(trial)
                    if (vt-credit).max() < (v-credit).max():
                        v, best_j = vt, trial[j]
                w[j] = best_j
            if (v-credit).max() >= prev:
                break
        output = dict(N=sum(counts), design=[list(x)+[n] for x,n in zip(settings,counts,strict=True)],
                      log_rounding_scale=self.scale, integer_scores=scores.tolist(),
                      integer_bias=w[self.classes].tolist(), representative_graphs=self.reps.tolist(),
                      approximate_pair_sums=v.tolist(), approx_max_error_upper=float(v.max()))
        return output, w


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    parser.add_argument("--totals", nargs="+", type=int, default=(102,101))
    parser.add_argument("--refine-101", action="store_true", help="Extend t2 and rescale the integer scores for 101 shots")
    args = parser.parse_args()
    best = {}
    visited = set()

    def run(s, ts, ns):
        key = (s.scale,ts,ns)
        if key in visited:
            return
        visited.add(key)
        total = sum(ns)
        old, wold = best.get(total, ({}, None))
        if old:
            wold = wold * s.scale / old["log_rounding_scale"]
        result, w = s.test(ts, ns, wold)
        mx = result["approx_max_error_upper"]
        if not old or mx < old["approx_max_error_upper"]:
            best[total] = result, w
            path = args.output_dir / f"time_candidate_{total}.json"
            path.write_text(json.dumps(result), encoding="utf-8")
            print("BEST", total, s.scale, ts, ns, mx, result["approximate_pair_sums"], flush=True)

    s = BiasScreen(32)
    for total in args.totals:
        for j in (13,11,15,9,17):
            run(s, (2.104,3.036),(total-j,j))
        for d in (0.032,-0.032,0.064,-0.064,0.096,-0.096,0.128,-0.128):
            run(s, (round(2.104+d,3),3.036),(total-13,13))
            run(s, (2.104,round(3.036+d,3)),(total-13,13))
        for step in (0.048,0.024,0.012,0.006):
            for _ in range(2):
                b = best[total][0]["design"]
                ta,tb = b[0][1],b[1][1]
                j = b[1][2]
                for da, db, dj in ((step,0,0),(-step,0,0),(0,step,0),(0,-step,0),(0,0,1),(0,0,-1)):
                    run(s,(round(ta+da,3),round(tb+db,3)),(total-j-dj,j+dj))

    if args.refine_101 and 101 in best:
        for tb in (3.292,3.324,3.356,3.388,3.420,3.452,3.484,3.516):
            for j in (9,11,13):
                run(s,(2.128,tb),(101-j,j))
        for step in (0.024,0.012,0.006):
            for _ in range(3):
                (_,ta,_),(_,tb,j) = best[101][0]["design"]
                for da,db,dj in ((step,0,0),(-step,0,0),(0,step,0),(0,-step,0),(0,0,1),(0,0,-1)):
                    run(s,(round(ta+da,3),round(tb+db,3)),(101-j-dj,j+dj))
        for scale in (64,48,96,128,24):
            s = BiasScreen(scale)
            for a,b,c in ((2.122,3.504,11),(2.128,3.516,11),(2.125,3.510,11),
                          (2.122,3.492,11),(2.122,3.528,11),(2.134,3.504,11),
                          (2.122,3.504,10),(2.122,3.504,12),(2.116,3.504,11)):
                run(s,(a,b),(101-c,c))


if __name__ == "__main__":
    main()
