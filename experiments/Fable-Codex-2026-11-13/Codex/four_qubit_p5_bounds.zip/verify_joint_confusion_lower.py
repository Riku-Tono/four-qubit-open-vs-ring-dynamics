"""Check a shared-confusion multi-hypothesis lower witness using integer arithmetic."""
import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from itertools import permutations
import json
from math import ceil
from pathlib import Path

from exact_topology_lower import BONDS, ROOT_SCALE, STEPS, distance_upper_ticks, root_grid


P = Fraction(1, 20)
EPS = Fraction(1, 20)


def site_maps():
    maps = []
    for pi in permutations(range(4)):
        bit_map = [1 << BONDS.index(tuple(sorted((pi[i], pi[j])))) for i,j in BONDS]
        maps.append([sum(bit_map[k] for k in range(6) if g & (1 << k)) for g in range(64)])
    return maps


def log_threshold_lower(pairs, z_values, tangent_rows):
    maps = site_maps()
    vertices = sorted({mapping[g] for a,b,_ in pairs for g in (a,b) for mapping in maps})
    outcomes = [*vertices, -1]
    normalized = [Fraction(w, sum(v for _,_,v in pairs)) for _,_,w in pairs]

    def canonical(i,j):
        if j == -1:
            return min(m[i] for m in maps), -1
        return min((m[i],m[j]) for m in maps)

    coefficients = defaultdict(Fraction)
    log_part = Fraction()
    for (a,b,_),w,z,terms in zip(pairs,normalized,z_values,tangent_rows,strict=True):
        assert w > 0 and 0 < z < 1
        # -log(z) >= sum_{n=1}^{100} (1-z)^n / n.
        log_part += w * (1 + sum(((1-z)**h/h for h in range(1,101)), Fraction()))
        for j,u in zip(outcomes,terms,strict=True):
            assert u > 0
            coefficients[canonical(a,j)] += w*u/(2*z)
            coefficients[canonical(b,j)] += w/(2*z*u)
    max_affine = Fraction()
    for g in sorted({min(m[i] for m in maps) for i in vertices}):
        row = Counter(canonical(g,j) for j in outcomes)
        diagonal = coefficients[g,g]
        # Each row has >=19/20 mass at the correct label. The remaining
        # 1/20 can be freely assigned and contributes at most the best
        # coefficient per unit of probability mass.
        max_affine += (1-EPS)*diagonal + EPS*max(coefficients[key]/d for key,d in row.items())
    return log_part - max_affine


def time_upper(pairs):
    points = sorted({g for a,b,_ in pairs for g in (a,b)})
    roots = {g: root_grid(g,[P])[P] for g in points}
    peak = 0
    where = None
    for i in range(STEPS+1):
        for k in range(3):
            total = sum(w*distance_upper_ticks(roots[a][i][k],roots[b][i][k]) for a,b,w in pairs)
            if total > peak:
                peak, where = total, (i,k)
    return Fraction(peak,ROOT_SCALE*sum(w for _,_,w in pairs)), where


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("witness",type=Path)
    parser.add_argument("output",type=Path)
    args = parser.parse_args()
    witness = json.loads(args.witness.read_text(encoding="utf-8"))
    pairs = witness["pair_weights"]
    z = [Fraction(s) for s in witness["log_tangents"]]
    u = [[Fraction(s) for s in row] for row in witness["affinity_tangents"]]
    d = log_threshold_lower(pairs,z,u)
    print("joint confusion D >=",float(d),flush=True)
    m,where = time_upper(pairs)
    bound = d/m
    payload = dict(weighted_B_upper=str(m), weighted_B_upper_at=dict(grid_node=where[0],basis="XYZ"[where[1]]),
                   joint_log_threshold_lower=str(d), ratio_floor_6=str((bound*10**6).__floor__()),
                   necessary_N_integer=ceil(bound))
    args.output.write_text(json.dumps(payload,indent=2)+"\n",encoding="utf-8")
    print("necessary N", ceil(bound), "real >=",float(bound),flush=True)


if __name__=="__main__":
    main()
