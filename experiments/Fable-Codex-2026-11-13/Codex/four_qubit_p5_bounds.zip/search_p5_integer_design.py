"""Explore bounded pairwise classification error for integer-score decoders."""
import argparse
from dataclasses import dataclass
from itertools import permutations
import json
from pathlib import Path

import numpy as np
from scipy.fft import irfft, next_fast_len, rfft
from scipy.optimize import differential_evolution

import finite_shot_topology as model


def graph_symmetry():
    maps = []
    for permutation in permutations(range(4)):
        transformed_bits = [1 << model.PAIRS.index(tuple(sorted((permutation[i], permutation[j]))))
                            for i, j in model.PAIRS]
        maps.append([sum(transformed_bits[edge] for edge in range(6) if graph & (1 << edge))
                     for graph in range(64)])
    maps = np.array(maps)
    representative = maps.min(axis=0)
    representatives, classes = np.unique(representative, return_inverse=True)
    pairs = []
    for true_graph in representatives:
        stabilizer = maps[maps[:, true_graph] == true_graph]
        representatives_under_stabilizer = stabilizer.min(axis=0)
        for rival, multiplicity in zip(*np.unique(representatives_under_stabilizer, return_counts=True)):
            if rival != true_graph:
                pairs.append((int(true_graph), int(rival), int(multiplicity)))
    return representatives, classes, pairs


@dataclass
class PairTail:
    true_class: int
    rival_class: int
    multiplicity: int
    minimum: int
    tail: np.ndarray


def score_distribution(delta, probabilities, shots):
    lo = delta.min(axis=1)
    span = delta.max(axis=1) - lo
    support = int(np.dot(span, shots)) + 1
    fft_size = next_fast_len(support, real=True)
    transform = np.ones(fft_size // 2 + 1, dtype=np.complex128)
    for values, p, n, minimum in zip(delta, probabilities, shots, lo, strict=True):
        if n:
            polynomial = np.bincount(values - minimum, weights=p)
            transform *= rfft(polynomial, n=fft_size) ** n
    mass = irfft(transform, n=fft_size)[:support]
    tail = np.maximum(mass, 0)[::-1].cumsum()[::-1]
    return int(np.dot(lo, shots)), tail


def tails_for_all_pairs(scores, probabilities, shots, classes, pairs):
    records = []
    for g, h, m in pairs:
        minimum, tail = score_distribution(scores[h] - scores[g], probabilities[g], shots)
        records.append(PairTail(classes[g], classes[h], m, minimum, tail))
    return records


class MinimizeWorstPairSum:
    def __init__(self, records, classes, bound):
        self.class_count = classes
        self.true = np.array([r.true_class for r in records])
        self.rival = np.array([r.rival_class for r in records])
        self.multiplicities = np.array([r.multiplicity for r in records])
        self.bound = bound
        offsets = np.arange(-2 * bound, 2 * bound + 1)
        values = []
        for r in records:
            indices = offsets - r.minimum
            values.append(np.where(indices < 0, 1, np.where(indices >= len(r.tail), 0,
                r.tail[np.clip(indices, 0, len(r.tail) - 1)])))
        self.tail = np.array(values)
        self.rows = np.arange(len(records))

    def values(self, weights):
        shifts = weights[self.true] - weights[self.rival] + 2 * self.bound
        return np.bincount(self.true, weights=self.tail[self.rows, shifts] * self.multiplicities,
                           minlength=self.class_count)

    def optimize(self, seed):
        def objective(x):
            weights = np.r_[0, np.rint(x).astype(int)]
            values = self.values(weights)
            return values.max() + 0.02 * (values**8).sum()**0.125

        optimized = differential_evolution(objective, [(-self.bound, self.bound)] * (self.class_count - 1),
                                            maxiter=115, popsize=8, rng=seed, polish=False, tol=0.002)
        return np.r_[0, np.rint(optimized.x).astype(int)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--totals", nargs="+", type=int, default=(104, 102, 100, 98, 96, 94, 92))
    args = parser.parse_args()
    settings = [("X", 2.260), ("Z", 2.104), ("Z", 3.036)]
    scale = 32
    probabilities = model.setting_probs(settings, 0.05)
    probabilities /= probabilities.sum(axis=2, keepdims=True)
    scores = np.rint(scale * np.log(probabilities)).astype(int)
    reps, classes, pairs = graph_symmetry()
    print(f"{len(reps)} graph orbits, {len(pairs)} directed pair orbits", flush=True)
    best = None
    for total in args.totals:
        for x_count, z2_count in ((5, 10), (0, 13), (10, 9), (5, 15), (8, 18), (2, 21)):
            shots = (x_count, total - x_count - z2_count, z2_count)
            records = tails_for_all_pairs(scores, probabilities, shots, classes, pairs)
            objective = MinimizeWorstPairSum(records, len(reps), scale * 2)
            weight = objective.optimize(2026111317)
            initial = objective.values(np.zeros(len(reps), dtype=int)).max()
            bound = objective.values(weight)
            print(f"{total} {shots} raw {initial:.6f} weighted {bound.max():.6f} weights {weight.tolist()}", flush=True)
            if bound.max() < 0.05 and (best is None or total < best["N"] or
                                       (total == best["N"] and bound.max() < best["approx_max_error_upper"])):
                best = dict(N=total, design=[list(setting) + [n] for setting, n in zip(settings, shots, strict=True)],
                            approximate_pair_sums=bound.tolist(), approx_max_error_upper=float(bound.max()),
                            representative_graphs=reps.tolist(), classes=classes.tolist(),
                            integer_scores=scores.tolist(), integer_bias=weight[classes].tolist(),
                            log_rounding_scale=scale)
                args.output.write_text(json.dumps(best, indent=2), encoding="utf-8")
        if best is not None and total > best["N"] - 5 and total < best["N"]:
            break


if __name__ == "__main__":
    main()
